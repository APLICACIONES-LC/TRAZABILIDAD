/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CODIGO_DE_BARRAS;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 *
 * @author ERICK IVAN
 */
public class prueba {
    public static void main(String []args){
        
     Date date = new Date();

DateFormat hourFormat = new SimpleDateFormat("HH:mm:ss");

DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

DateFormat hourdateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
System.out.println("Hora y fecha: "+hourdateFormat.format(date));
        
//        
//      SimpleDateFormat formateador = new SimpleDateFormat("dd'-'MM'-'yyyy", new Locale("es_ES"));
//   Date fechaDate = new Date();
//   String fecha = formateador.format(fechaDate);
//   System.out.println(fecha);
    }
     public static String getFechaActual() {
     
         
         
         
         Date ahora = new Date();
        SimpleDateFormat formateador = new SimpleDateFormat("dd-MM-yyyy");
         System.out.println(""+ahora);
        return formateador.format(ahora);
    }
}
