/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constantes;

/**
 *
 * @author ERICK IVAN
 */
public class Constantes {

    public static String ID;

    public static String CANTIDAD;

    public static String NOMBRE_PAQUETE;

    public static String ID_USUARIO;

    public static String ID_TIPO_USUARIO;

    public static String ID_NOMBRE_USUARIO;

    public static String CENTRO = "APLICACIONES LC HOSPITAL";

    public static String CODIGO_DE_BARRAS;

    public static String INCLUYE;

    public static String DEPARTAMENTO;

    public static String ENVIAR_A;

    public static String ULTIMO_DIGITO;

    public static String ID_INSTRUMENTOS;

    public static String ID_CIRUGIAS;

    public static String DIRECCION_PDF;

    public static String ID_INSTRUMENTO_IMAGEN;

     public static boolean VENTANAS=false;
}
