/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_UPDATE;

import CONEXION.Conectar;
import Constantes.Constantes;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class UPDATE_INSTRUMENTOS_IMAGEN {
    
 //////////////////////////CONEXIÓN////////////////////  
 Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
 /////////////////////////////////////////////////////////   
 public boolean bandera=false;
       public void update_instrumentos(String dato1_nombre, String dato2_stock, String dato3_operacion, File archivo) throws FileNotFoundException{
       
        
    try {
        cnu.setAutoCommit(false); 
            String ins = "UPDATE tbl_instrumentos set str_nombre = ?, str_stock = ?, str_id_operacion = ?, str_imagen=?  where str_id = ? ";
         
            PreparedStatement pst = cnu.prepareStatement(ins); 
            pst.setString(1,  dato1_nombre);
            pst.setString(2,  dato2_stock);
            pst.setString(3, dato3_operacion);
            FileInputStream   fis = new FileInputStream(archivo);
           //Lo convertimos en un Stream
            pst.setBinaryStream(4, fis, (int) archivo.length());  
            
            pst.setString(5, Constantes.ID_INSTRUMENTOS);
             
            int n = pst.executeUpdate();
            if (n > 0) {
                bandera=true;
               cnu.commit();
             

            } else {
              //  
cnu.rollback();
cnu.close();
            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Se produjo un error al actualizar : "+ ex);
            Logger.getLogger(UPDATE_INSTRUMENTOS.class.getName()).log(Level.SEVERE, null, ex);
        }
      
} 

 
       
    
}
