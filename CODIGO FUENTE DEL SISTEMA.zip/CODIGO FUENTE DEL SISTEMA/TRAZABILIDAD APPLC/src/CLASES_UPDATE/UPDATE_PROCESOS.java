/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_UPDATE;

import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class UPDATE_PROCESOS {
    
  //////////////////////////CONEXIÓN////////////////////  
 Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
 /////////////////////////////////////////////////////////   
    
       public void update_procesos(String proceso1,String proceso2,String proceso3,String proceso4,String proceso5,String proceso6, String Codigo_de_barras){
       
        
    try {
       // cnu.setAutoCommit(false); 
            String ins = "UPDATE tbl_proceso set str_proceso1 = ?, str_proceso2 = ?, str_proceso3 = ?, str_proceso4 = ? , str_proceso5 = ?, str_proceso6 = ? where str_id = ? ";
            PreparedStatement pst = cnu.prepareStatement(ins); 
             pst.setString(1,  proceso1);
             pst.setString(2,  proceso2);
             pst.setString(3, proceso3);
             pst.setString(4, proceso4);
             pst.setString(5, proceso5);
             pst.setString(6, proceso6);
             pst.setString(7, Codigo_de_barras);
             
            int n = pst.executeUpdate();
            if (n > 0) {
               // JOptionPane.showMessageDialog(null, "Actualizando el STOCK y OPERACIÓN", "Sistema ", JOptionPane.DEFAULT_OPTION, null);
System.out.println("actualizacion con exito");
            } else {
               // JOptionPane.showMessageDialog(null, "La actualización tuvo problemas", "Sistema ", JOptionPane.ERROR_MESSAGE);
System.out.println("fracaso en la actualizacion");
            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Se produjo un error al actualizar : "+ ex);
            Logger.getLogger(UPDATE_STOCK_INSTRUMENTOS.class.getName()).log(Level.SEVERE, null, ex);
        }
        
} 
}
