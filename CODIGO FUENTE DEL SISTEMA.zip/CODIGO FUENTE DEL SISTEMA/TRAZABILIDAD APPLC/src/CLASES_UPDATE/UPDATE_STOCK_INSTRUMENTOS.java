/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_UPDATE;

import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 *
 * @author ERICK IVAN
 */
public class UPDATE_STOCK_INSTRUMENTOS {
    //////////////////////////CONEXIÓN////////////////////  
 Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
 /////////////////////////////////////////////////////////   
 boolean bandera=false;
       public void update_instrumentos(String dato1_nombre, int dato2_cantidad){
       
        
    try {
        cnu.setAutoCommit(false); 
            String ins = "UPDATE tbl_instrumentos set str_stock = str_stock ?, str_en_operacion = str_en_operacion + ?  where str_id = ? ";
            PreparedStatement pst = cnu.prepareStatement(ins); 
             pst.setInt(1,  - dato2_cantidad);
            pst.setInt(2,  dato2_cantidad);
             pst.setString(3, dato1_nombre);
             
            int n = pst.executeUpdate();
            if (n > 0) {
               cnu.commit();
             

            } else {
              //  
cnu.rollback();
cnu.close();
            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Se produjo un error al actualizar : "+ ex);
            Logger.getLogger(UPDATE_STOCK_INSTRUMENTOS.class.getName()).log(Level.SEVERE, null, ex);
        }
      
} 
       
    
}
