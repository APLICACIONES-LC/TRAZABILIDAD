/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_UPDATE;

import CONEXION.Conectar;
import static Constantes.Constantes.CODIGO_DE_BARRAS;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class UPDATE_OPERANDO {
    
  //////////////////////////CONEXIÓN////////////////////  
 Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
 /////////////////////////////////////////////////////////   
    
       public void update_operacion_tbl_paquete(){
       
        
    try {
        cnu.setAutoCommit(false); 
            String ins = "UPDATE tbl_paquete set str_operacion =  ?  where str_id_paquete = ? ";
            PreparedStatement pst = cnu.prepareStatement(ins);
            pst.setString(1,  "operando");
             pst.setString(2, CODIGO_DE_BARRAS);
             
            int n = pst.executeUpdate();
            if (n > 0) {
                JOptionPane.showMessageDialog(null, "Excelente paquete en operación", "Sistema ", JOptionPane.DEFAULT_OPTION, null);
metodo_commit();
            } else {
                JOptionPane.showMessageDialog(null, "Se encontro un error al momento de actualizar este paquete", "Sistema ", JOptionPane.ERROR_MESSAGE);

            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Se produjo un error al actualizar : "+ ex);
            Logger.getLogger(UPDATE_OPERANDO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
public void metodo_commit() throws SQLException{
    cnu.commit();
}
   
    
}
