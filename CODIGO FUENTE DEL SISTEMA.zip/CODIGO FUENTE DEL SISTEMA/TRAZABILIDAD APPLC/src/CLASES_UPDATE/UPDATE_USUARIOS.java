/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_UPDATE;

import CONEXION.Conectar;
import Constantes.Constantes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class UPDATE_USUARIOS {
//////////////////////////CONEXIÓN////////////////////  
 Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
 /////////////////////////////////////////////////////////   
 public boolean bandera=false;
       public void update_usuario(String dato1, String dato2, String dato3, String dato4, String dato5, String dato6){
       
        
    try {
        cnu.setAutoCommit(false); 
            String ins = "UPDATE tbl_usuario set str_n_usuario= ? , str_n_contra= ? , str_nombre= ? , str_apellidos= ? , str_t_usuario = ?  where str_id_usuario = ? ";
            PreparedStatement pst = cnu.prepareStatement(ins); 
            pst.setString(1,  dato2);
            pst.setString(2,  dato3);
            pst.setString(3,  dato4);
            pst.setString(4,  dato5);
            pst.setString(5,  dato6);
            pst.setString(6,  dato1);
             
            int n = pst.executeUpdate();
            if (n > 0) {
                JOptionPane.showMessageDialog(null, "Actualizacion exitosa");
                bandera=true;
               cnu.commit();
             } else {
              //  
cnu.rollback();
cnu.close();
            }
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Se produjo un error al actualizar : "+ ex);
            Logger.getLogger(UPDATE_CIRUGIAS.class.getName()).log(Level.SEVERE, null, ex);
        }
      
} 

 
       
    
}
