/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package REPORTES_PDF;

import Constantes.Constantes;
import static Constantes.Constantes.CODIGO_DE_BARRAS;
import IMPRESORA.PrintTest;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.ZapfDingbatsList;
import com.itextpdf.text.pdf.Barcode;
import com.itextpdf.text.pdf.BarcodeEAN;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class Reporte_code_barras {


    public void PDF(){
        Rectangle pageSize = new Rectangle(149f, 220f); //ancho y alto
        //////////////////////////////////52.832||70.612
Document document = new Document(pageSize,15,10,10,10);
// Document document = new Document(PageSize.A6, 50, 10, 10, 10);
        try {

            // El archivo pdf que vamos a generar
            FileOutputStream fileOutputStream = new FileOutputStream( "ticket.pdf");

            // Obtener la instancia del PdfWriter
        PdfWriter pdfw=    PdfWriter.getInstance(document, fileOutputStream);

            // Abrir el documento
            document.open();
            
  
   
   
 
//            Image image = null;
            // Obtenemos el logo de datojava
            
//            image = Image.getInstance("hospital.png");
//            image.scaleAbsolute(50f, 40f);
            // Crear las fuentes para el contenido y los titulos
            Font fontContenido = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.NORMAL, BaseColor.DARK_GRAY);
            Font fontTitulos = FontFactory.getFont(  FontFactory.TIMES_BOLDITALIC, 7, Font.UNDERLINE,  BaseColor.RED);
             Font fontTitulo_PRIN = FontFactory.getFont(  FontFactory.TIMES_BOLDITALIC, 8, Font.NORMAL,  BaseColor.BLACK);

            // Creacion de una tabla
            PdfPTable table = new PdfPTable(1);

            // Agregar la imagen anterior a una celda de la tabla
//            PdfPCell cell = new PdfPCell(image);
            // Propiedades de la celda
//            cell.setColspan(5);
//            cell.setBorderColor(BaseColor.WHITE);
//            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);

            // Agregar la celda a la tabla
//            table.addCell(cell);

            // Agregar la tabla al documento
            document.add(table);

            
            /////////////////////////////////////////////
            Paragraph paragraph12 = new Paragraph();//////////////////////////
           paragraph12.add(new Phrase(Constantes.CENTRO,fontTitulo_PRIN));///////////////////////QUITAR EN CASO DE ERROR
         
 document.add(paragraph12);//////////////////////////////////////////////////
          
 Image img; 
   //Es el tipo de clase 
   BarcodeEAN codeEAN = new BarcodeEAN();
   //Seteo el tipo de codigo
   codeEAN.setCodeType(Barcode.EAN13);
   //Setep el codigo
   codeEAN.setCode(CODIGO_DE_BARRAS);
   //Paso el codigo a imagen
   img = codeEAN.createImageWithBarcode( pdfw.getDirectContent(), BaseColor.BLACK, BaseColor.BLACK);
   //Agrego la imagen al documento
   document.add(img); 
           
            
////////////////////////////////////////////////////
                    // Creacion del parrafo
            Paragraph paragraph = new Paragraph();
           
            paragraph.add(new Phrase("Datos:", fontTitulos));

            // Agregar el parrafo al documento
            document.add(paragraph);

            // La lista final
            List listaFinal = new List(List.UNORDERED);
            ListItem listItem = new ListItem();
            List list = new List();

            // Crear sangria en la lista
            list.setListSymbol(new Chunk(""));
            ListItem itemNuevo = new ListItem("");

            // ZapfDingbatsListm, lista con simbolos
            List listSymbol = new ZapfDingbatsList(51);
     Date date = new Date();

DateFormat hourFormat = new SimpleDateFormat("HH:mm:ss");

DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

DateFormat hourdateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
System.out.println("Hora y fecha: "+hourdateFormat.format(date));
            // Agregar contenido a la lista
            listSymbol.add(new ListItem("Departamento: "+Constantes.DEPARTAMENTO, fontContenido));
            listSymbol.add(new ListItem("Paquete: "+Constantes.NOMBRE_PAQUETE, fontContenido));
            listSymbol.add(new ListItem(Constantes.ENVIAR_A, fontContenido));
            listSymbol.add(new ListItem("Autorizo: "+Constantes.ID_NOMBRE_USUARIO, fontContenido));
            listSymbol.add(new ListItem("Fecha: "+hourdateFormat.format(date), fontContenido));
           ///////////////////////////"Enviar A: "+

            itemNuevo.add(listSymbol);
            list.add(itemNuevo);
            listItem.add(list);

            // Agregar todo a la lista final
            listaFinal.add(listItem);

            // Agregar la lista
            document.add(listaFinal);

          
           
            
            // Cerrar el documento
            document.close();
Constantes.DIRECCION_PDF="ticket.pdf";
//             Abrir el archivo
//            File file = new File("reporteinstrumentos.pdf");
//            Desktop.getDesktop().open(file);
          PrintTest PT=new PrintTest();
          PT.imprime();
//	File fileToPrint = new File("ticket.pdf");
//		Desktop.getDesktop().print(fileToPrint);
        } catch (DocumentException | IOException ex) {
            JOptionPane.showMessageDialog(null, ex+" no se");
//            ex.printStackTrace();
        }
        
         
    }
    //int global=0;

 	
}    
   