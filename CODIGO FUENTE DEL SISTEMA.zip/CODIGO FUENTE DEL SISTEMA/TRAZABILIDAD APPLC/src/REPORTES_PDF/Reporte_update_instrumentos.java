/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package REPORTES_PDF;

import Constantes.Constantes;
import static Constantes.Constantes.CODIGO_DE_BARRAS;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.ZapfDingbatsList;
import com.itextpdf.text.pdf.Barcode;
import com.itextpdf.text.pdf.BarcodeEAN;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class Reporte_update_instrumentos {
 public ArrayList<String> TABLA_LISTA = new ArrayList<>();

    public void PDF(){
 Document document = new Document(PageSize.A4, 35, 30, 50, 50);
        try {

            // El archivo pdf que vamos a generar
            FileOutputStream fileOutputStream = new FileOutputStream( "reporte_finalizacion_de_instrumentos.pdf");

            // Obtener la instancia del PdfWriter
        PdfWriter pdfw=    PdfWriter.getInstance(document, fileOutputStream);

            // Abrir el documento
            document.open();
            
  
   
   
 
            Image image = null;
            // Obtenemos el logo de datojava
            
            image = Image.getInstance("logo.png");
            image.scaleAbsolute(80f, 60f);
            // Crear las fuentes para el contenido y los titulos
            Font fontContenido = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.NORMAL, BaseColor.DARK_GRAY);
            Font fontTitulos = FontFactory.getFont(  FontFactory.TIMES_BOLDITALIC, 9, Font.UNDERLINE,  BaseColor.RED);

            // Creacion de una tabla
            PdfPTable table = new PdfPTable(1);

            // Agregar la imagen anterior a una celda de la tabla
            PdfPCell cell = new PdfPCell(image);
            // Propiedades de la celda
            cell.setColspan(5);
            cell.setBorderColor(BaseColor.WHITE);
            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);

            // Agregar la celda a la tabla
            table.addCell(cell);

            // Agregar la tabla al documento
            document.add(table);

            
            /////////////////////////////////////////////
            Paragraph paragraph12 = new Paragraph();//////////////////////////
           paragraph12.add(new Phrase(Constantes.CENTRO));///////////////////////QUITAR EN CASO DE ERROR
         
 document.add(paragraph12);//////////////////////////////////////////////////
          
 Image img; 
   //Es el tipo de clase 
   BarcodeEAN codeEAN = new BarcodeEAN();
   //Seteo el tipo de codigo
   codeEAN.setCodeType(Barcode.EAN13);
   //Setep el codigo
   codeEAN.setCode(CODIGO_DE_BARRAS);
   //Paso el codigo a imagen
   img = codeEAN.createImageWithBarcode( pdfw.getDirectContent(), BaseColor.BLACK, BaseColor.BLACK);
   //Agrego la imagen al documento
   document.add(img); 
           
            
////////////////////////////////////////////////////
                    // Creacion del parrafo
            Paragraph paragraph = new Paragraph();
           
            paragraph.add(new Phrase("   Datos principales:", fontTitulos));

            // Agregar el parrafo al documento
            document.add(paragraph);

            // La lista final
            List listaFinal = new List(List.UNORDERED);
            ListItem listItem = new ListItem();
            List list = new List();

            // Crear sangria en la lista
            list.setListSymbol(new Chunk(""));
            ListItem itemNuevo = new ListItem("");

            // ZapfDingbatsListm, lista con simbolos
            List listSymbol = new ZapfDingbatsList(51);

            // Agregar contenido a la lista
            listSymbol.add(new ListItem("Nombre del operario: "+Constantes.ID_NOMBRE_USUARIO, fontContenido));
            listSymbol.add(new ListItem("Cantidad total regresada: "+Constantes.CANTIDAD, fontContenido));
            listSymbol.add(new ListItem("Centro: "+Constantes.CENTRO, fontContenido));
            listSymbol.add(new ListItem("Unidad: "+ Constantes.DEPARTAMENTO+", "+ new Date(), fontContenido));

            itemNuevo.add(listSymbol);
            list.add(itemNuevo);
            listItem.add(list);

            // Agregar todo a la lista final
            listaFinal.add(listItem);

            // Agregar la lista
            document.add(listaFinal);

            paragraph = new Paragraph();
            paragraph.add(new Phrase(Chunk.NEWLINE));
            paragraph.add(new Phrase(Chunk.NEWLINE));
      
          
          document.add(paragraph);
    
          
   ////////////////////////////////////////////////////////-----------------------------------------------------------------------------------------       
//  // Obtenemos el logo de datojava
//            image = Image.getInstance("codigo.png");
//            image.scaleAbsolute(150f, 100f);
// 
// // Creacion de una tabla
//            PdfPTable table2 = new PdfPTable(1);
//
//            // Agregar la imagen anterior a una celda de la tabla
//            PdfPCell cell2 = new PdfPCell(image);
//
//              // Propiedades de la celda
//            cell2.setColspan(5);
//            cell2.setBorderColor(BaseColor.WHITE);
//            cell2.setHorizontalAlignment(Element.ALIGN_RIGHT);
//
//            // Agregar la celda a la tabla
//            table2.addCell(cell2);
//
//            // Agregar la tabla al documento
//            document.add(table2);

//            // Cargar otra imagen
//		    table = new PdfPTable(1);
//                         table.setWidthPercentage(100);
//           image = Image.getInstance(paciente+".png");
//           image.scaleAbsolute(100, 100);
//           image.setRotationDegrees(270);
//           
//            
//            table.addCell(image);
//
//            // Agregar la tabla al documento
//            document.add(table);

  /////////////////--------------------------------------------------------------------------------------------------------------------
               Paragraph parah = new Paragraph();
            // Agregar un titulo con su respectiva fuente
            parah .add(new Phrase("   Tabla de instrumentos regresados", fontTitulos));
            // Agregar saltos de linea
            parah .add(new Phrase(Chunk.NEWLINE));
            parah .add(new Phrase(Chunk.NEWLINE));
    document.add(parah );

       //////////////////////////////////////////////////////////////////            
            
            
    
            
                 //////////////////////////////
             PdfPCell celda1 =new PdfPCell (new Paragraph("IDENTIFICADOR INSTRUMENTO",FontFactory.getFont("arial",11,Font.BOLD,BaseColor.RED)));
             PdfPCell celda2 =new PdfPCell (new Paragraph("NOMBRE",FontFactory.getFont("arial",11,Font.BOLD,BaseColor.RED)));
             PdfPCell celda3 =new PdfPCell (new Paragraph("CANTIDAD",FontFactory.getFont("arial",11,Font.BOLD,BaseColor.RED)));   
             
              
            
              PdfPTable table4 = new PdfPTable(3);                
            table4.setWidthPercentage(100);
             float[] values = new float[3];
            values[0] = 25;
            values[1] = 50;
            values[2] = 25;
        
          
            table4.setWidths(values);
             
            table4.addCell(celda1);
             table4.addCell(celda2);
             table4.addCell(celda3);
            // addCell() agrega una celda a la tabla, el cambio de fila
            // ocurre automaticamente al llenar la fila
                for (int i = 0; i <= TABLA_LISTA.size() - 1; i++) {
                    table4.addCell(""+TABLA_LISTA.get(i));
                }
            
           
            // Si desea crear una celda de mas de una columna
            // Cree un objecto Cell y cambie su propiedad span
            
            PdfPCell celdaFinal = new PdfPCell(new Paragraph("Estos instrumentos fueron actualizados al stock de cada pieza"));
            
            // Indicamos cuantas columnas ocupa la celda
             
            celdaFinal.setColspan(3);
            table4.addCell(celdaFinal);
            
            // Agregamos la tabla al documento            
            document.add(table4);
            
            
            /////////////////
            // Agregar un titulo con su respectiva fuente
            paragraph.add(new Phrase("   Observaciones:", fontTitulos));

            // Agregar saltos de linea
            paragraph.add(new Phrase(Chunk.NEWLINE));
            

            // Agregar contenido con su respectiva fuente
            paragraph.add(new Phrase(" NOTA:\nEl instrumento quirurgico esta sucio por favor de llevarlo al area de \"LAVADO\" para"
                    + "que le realizen su lavado correspondiente para despues ser guardados en almacen\n", fontContenido));

            paragraph.add(new Phrase(Chunk.NEWLINE));
           
            document.add(paragraph);

 
            //////////////////////////////////////////////////////
            
            
            
//            // Crear tabla nueva con dos posiciones
//            table = new PdfPTable(2);
//            float[] longitudes = {5.0f, 5.0f};
//
//            // Establecer posiciones de celdas
//            table.setWidths(longitudes);
//            cell = new PdfPCell();
//
//            // Cargar imagenes del producto y agregarlas
//            image = Image.getInstance("APLICACIONES LC.png");
//            image.scaleAbsolute(10f, 10f);
//            table.getDefaultCell().setBorderColor(BaseColor.WHITE);
//            table.addCell(image);
//            image = Image.getInstance("APLICACIONES LC.png");
//            image.scaleAbsolute(10f, 10f);
//            table.addCell(image);
//
//            // Agregar la tabla al documento
//            document.add(table);

            
            
            // Cerrar el documento
            document.close();
Constantes.DIRECCION_PDF="reporte_finalizacion_de_instrumentos.pdf";
//             Abrir el archivo
//            File file = new File("reporteinstrumentos.pdf");
//            Desktop.getDesktop().open(file);
//          PrintTest PT=new PrintTest();
//          PT.imprime();
File fileToPrint = new File("reporte_finalizacion_de_instrumentos.pdf");
		Desktop.getDesktop().print(fileToPrint);
        } catch (DocumentException | IOException ex) {
            JOptionPane.showMessageDialog(null, ex);
//            ex.printStackTrace();
        }
        
         
    }
    //int global=0;

 	
}    
   

