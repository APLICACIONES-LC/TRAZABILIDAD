/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONEXION;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class Conectar {
 Connection conect = null;
   public Connection conexion(){
      try {
           Class.forName("org.mariadb.jdbc.Driver");
           conect = DriverManager.getConnection("jdbc:mariadb://localhost:3306/bd_instrumentacion","root","tu contraseña aquí");          
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null,"Error "+e);
        }
        return conect;
     
}
   


 public void closeConnection() {
        try {
            conect.close();
            JOptionPane.showMessageDialog(null, "Se ha finalizado la conexión con el servidor");
        } catch (SQLException ex) {
            Logger.getLogger(Conectar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
