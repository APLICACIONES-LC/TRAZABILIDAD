/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_SELECT;


import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class SELECT_NOTIFICACION {
    
            /////////////////////////////////////////////conexión//////////
    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
    
    public String dato1="",dato2="",dato3="",dato4="",dato5="",dato6="",dato7="",dato8="",dato9="",dato10="";
    
    /////////////////////////////////////////////////////////
    public void notificacion(){
               String sqll = "SELECT * FROM tbl_proceso ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                 dato1 = rss.getString("str_id");
                 dato2 = rss.getString("str_nombre");
                 dato3 = rss.getString("str_cantidad");
                 dato4 = rss.getString("str_incluye");
                 dato5 = rss.getString("str_proceso1");
                 dato6 = rss.getString("str_proceso2");
                 dato7 = rss.getString("str_proceso3");
                 dato8 = rss.getString("str_proceso4");
                 dato9 = rss.getString("str_proceso5");
                 dato10 = rss.getString("str_proceso6");

            
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
}
