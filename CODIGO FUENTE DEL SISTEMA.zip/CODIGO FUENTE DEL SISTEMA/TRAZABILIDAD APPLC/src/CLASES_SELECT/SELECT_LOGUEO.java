/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_SELECT;


import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author ERICK IVAN
 */
public class SELECT_LOGUEO {
           /////////////////////////////////////////////conexión//////////
Conectar cu = new Conectar();
Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
    public boolean cerrar_ventana=false;
    public void logue(String usuario, String password) throws SQLException{
     
         String cap = "";
         String id = "";
         String NOMBRE = "",APELLIDO="";
        
        //Creo la sentencia SQl precompilada
PreparedStatement pstmt = cnu.prepareStatement("SELECT * FROM tbl_usuario WHERE str_n_usuario = ? AND str_n_contra=?");

pstmt.setString(1, usuario);
pstmt.setString(2, password);
//Obtengo el resultado de la consulta
ResultSet rs = pstmt.executeQuery();


//Si encuentra algo imprime el primer campo de los registro
while (rs.next()) {
        id=rs.getString("str_id_usuario");
        cap = rs.getString("str_t_usuario");
      NOMBRE=rs.getString("str_nombre");
    APELLIDO=rs.getString("str_apellidos");
  Constantes.Constantes.ID_USUARIO=id;
  Constantes.Constantes.ID_NOMBRE_USUARIO=NOMBRE+" "+APELLIDO;
Constantes.Constantes.ID_TIPO_USUARIO=cap;
}
if(id.isEmpty()){
   Constantes.Constantes.ID_USUARIO="";
  Constantes.Constantes.ID_NOMBRE_USUARIO="";
Constantes.Constantes.ID_TIPO_USUARIO=""; 

}
  
            



    }
}
