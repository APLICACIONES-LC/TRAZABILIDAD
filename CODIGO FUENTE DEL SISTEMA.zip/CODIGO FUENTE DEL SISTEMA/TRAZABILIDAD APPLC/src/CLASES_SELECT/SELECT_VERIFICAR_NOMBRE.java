/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_SELECT;

import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class SELECT_VERIFICAR_NOMBRE {
             /////////////////////////////////////////////conexión//////////
    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
   public boolean bandera=true;
    ///////////////////////////////////////////////////////////
   String dato1="";
        public void notificacion(String nombre){
            
            String sqll = "SELECT * FROM tbl_proceso";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
              dato1 = rss.getString("str_nombre");
                     System.out.println("hola: "+dato1+" X2");  
if(dato1.equals(nombre)){
    bandera=false;
    break;
}else{
    
    bandera=true;
}
            
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_VERIFICAR_NOMBRE.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("hola:"+dato1+"X3"+"  "+bandera);  
    }
}
