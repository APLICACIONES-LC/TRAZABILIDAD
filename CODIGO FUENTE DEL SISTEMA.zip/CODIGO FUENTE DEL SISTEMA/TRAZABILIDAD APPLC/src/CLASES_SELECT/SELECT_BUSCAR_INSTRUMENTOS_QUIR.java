/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_SELECT;

import CONEXION.Conectar;
import Constantes.Constantes;
import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class SELECT_BUSCAR_INSTRUMENTOS_QUIR {
   /////////////////////////////////////////////conexión//////////

    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
   public boolean bandera=false;
   public String  dato1="",dato2="",dato3="",dato4="",dato5="";
    public Icon icon=null;
    public void select(String id) throws IOException{
               
        String sqll = "SELECT * FROM tbl_instrumentos where str_id='"+id+"'";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                dato1 = rss.getString("str_id");
                dato2 = rss.getString("str_nombre");
                dato3 = rss.getString("str_stock");
                dato4 = rss.getString("str_id_operacion");
                dato5 = rss.getString("str_en_operacion");
                
           byte[] img = rss.getBytes("str_imagen");
           Image picture = getImage(img, false);
  icon = new ImageIcon(picture);

if(dato1.equals("")){
    JOptionPane.showMessageDialog(null, "No se encontro ningun instrumento con el ID que ingreso","AVISO!!",JOptionPane.INFORMATION_MESSAGE);
}else{
     Constantes.ID_INSTRUMENTOS=dato1;
}
            
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_INSERT_QUIRURGICO.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    
    private Image getImage(byte[] bytes, boolean isThumbnail) throws IOException  {

ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
Iterator readers = ImageIO.getImageReadersByFormatName("png");
ImageReader reader = (ImageReader) readers.next();
       
Object source = bis; // File or InputStream
ImageInputStream iis = ImageIO.createImageInputStream(source);
reader.setInput(iis, true);
ImageReadParam param = reader.getDefaultReadParam();

if (isThumbnail) {

param.setSourceSubsampling(4, 4, 0, 0);
 
}
return reader.read(0, param);

}
    
}
