/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_SELECT;

import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class SELECT_INSERT_OPERACION_VALIDE {
        /////////////////////////////////////////////conexión//////////

    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
   public boolean bandera=false;
    public void select(String id){
         String  dato1="";           
        String sqll = "SELECT str_nombre_operacion FROM tbl_n_operacion";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                dato1 = rss.getString("str_nombre_operacion");
               if(dato1.equals(id)){
                   JOptionPane.showMessageDialog(null, "Ya existe el NOMBRE que quieres introducir");
             bandera=true;
                   break;
               }

            
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC INTERFACING", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_INSERT_QUIRURGICO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
