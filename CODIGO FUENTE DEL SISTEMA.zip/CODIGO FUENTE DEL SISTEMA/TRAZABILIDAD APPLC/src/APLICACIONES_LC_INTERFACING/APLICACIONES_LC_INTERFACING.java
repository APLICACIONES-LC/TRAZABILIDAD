/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package APLICACIONES_LC_INTERFACING;


import LOGIN.LOGUEO;

/**
 *
 * @author ERICK IVAN
 */
public class APLICACIONES_LC_INTERFACING {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       LOGUEO LO=new LOGUEO();
       LO.setVisible(true);
        
//        VENTANA_ADMINISTRADOR_MONITORISTA VAM=new VENTANA_ADMINISTRADOR_MONITORISTA();
//        VAM.setVisible(true);
    }
    
}
