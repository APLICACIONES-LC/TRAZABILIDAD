/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_INSERT;

import CLASE_CODIGO_FINAL.ULTIMO_DIGITO;
import CONEXION.Conectar;
import Constantes.Constantes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Erick
 */
public class INSERT_PAQUETE_A_NOTIFICACION {
        /////////////////////////////////////////////conexión//////////
    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
    public boolean mensaje=false;
    public void insertar(String nombre, int cantidad, ArrayList<String> TABLA_instrumentos, String Nombre_departamento){
      if(Nombre_departamento.equals("")){
          Nombre_departamento="Sin departamento";
          Constantes.DEPARTAMENTO=Nombre_departamento;
      }
      // long numero = ThreadLocalRandom.current().nextLong(0,7 + 1);
        long numero1 = ThreadLocalRandom.current().nextLong(1000,9000 + 1);
        long numero2 = ThreadLocalRandom.current().nextLong(10000,90000 + 1);
        
String codigo="750"+""+numero1+""+numero2;//+"7";
ULTIMO_DIGITO UD=new ULTIMO_DIGITO();
UD.controlCodeCalculator(codigo);

Constantes.CODIGO_DE_BARRAS=codigo+Constantes.ULTIMO_DIGITO;
        System.out.println("" + codigo);
        
        String lista_instrumentos=""+TABLA_instrumentos;
          System.out.println(""+lista_instrumentos);
              String ins = "INSERT INTO tbl_proceso (str_id,str_nombre,str_cantidad,str_incluye,str_departamento) VALUES(?,?,?,?,?)";
                try {
                    PreparedStatement pst = cnu.prepareStatement(ins);
                   pst.setString(1, Constantes.CODIGO_DE_BARRAS);
                    pst.setString(2, nombre);
                    pst.setInt(3, cantidad);
                   pst.setString(4, lista_instrumentos);
                   pst.setString(5, Nombre_departamento);
                    
                    int n = pst.executeUpdate();
//                    
//                   
                    if (n > 0) {
                        JOptionPane.showMessageDialog(null, "Se inserto correctamentente");
                  mensaje=true;     
                    } else {
                        JOptionPane.showMessageDialog(null, "Error, vuelva a intentarlo verifique que todos los campos\n"
                                + "estén llenos", "Sistema ", JOptionPane.ERROR_MESSAGE);
                        mensaje=false;
                    }
                    
                } catch (SQLException ex) {
                  mensaje=false;
                       JOptionPane.showMessageDialog(null, "Error, ocurrio un error imprevisto, vuelva a intentar y si el problema\n"
                               + "persiste favor de comunicarse con los especialistas de sistemas", "Sistema ", JOptionPane.ERROR_MESSAGE);
                         Logger.getLogger(INSERT_PAQUETE_A_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
                }
    }

 
}
