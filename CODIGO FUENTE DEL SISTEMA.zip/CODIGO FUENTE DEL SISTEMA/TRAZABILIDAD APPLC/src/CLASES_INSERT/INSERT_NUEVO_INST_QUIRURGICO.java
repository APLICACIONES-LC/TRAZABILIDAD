/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_INSERT;


import CONEXION.Conectar;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class INSERT_NUEVO_INST_QUIRURGICO {
      /////////////////////////////////////////////conexión//////////
    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
    public boolean mensaje=false;
    public void insertar(String dato1_id, String dato2_nombre_inst, String dato3_stock_inst, String dato4_operacion, File archivo) {
    
     String ins = "INSERT INTO tbl_instrumentos(str_id, str_nombre, str_stock, str_id_operacion,str_imagen) VALUES(?,?,?,?,?)";
                try {
                    PreparedStatement pst = cnu.prepareStatement(ins);
                   pst.setString(1,dato1_id);
                   pst.setString(2, dato2_nombre_inst);
                   pst.setString(3, dato3_stock_inst);
                   pst.setString(4, dato4_operacion);
                
 FileInputStream   fis = new FileInputStream(archivo);
 //Lo convertimos en un Stream
 pst.setBinaryStream(5, fis, (int) archivo.length());  
                    
                    int n = pst.executeUpdate();
//                    
//                   
                    if (n > 0) {
                        JOptionPane.showMessageDialog(null, "Se inserto correctamentente");
                  mensaje=true;     
                    } else {
                        JOptionPane.showMessageDialog(null, "Error, vuelva a intentarlo verifique que todos los campos\n"
                                + "estén llenos", "Sistema ", JOptionPane.ERROR_MESSAGE);
                        mensaje=false;
                    }
                    
                } catch (SQLException ex) {
                  mensaje=false;
                       JOptionPane.showMessageDialog(null, "Error, ocurrio un error imprevisto, vuelva a intentar y si el problema\n"
                               + "persiste favor de comunicarse con los especialistas de sistemas", "Sistema ", JOptionPane.ERROR_MESSAGE);
                         Logger.getLogger(INSERT_PAQUETE_A_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
                } catch (FileNotFoundException ex) {
                    
                    JOptionPane.showMessageDialog(null, "esto no es una imagen");
            Logger.getLogger(INSERT_NUEVO_INST_QUIRURGICO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   

   
  
}
