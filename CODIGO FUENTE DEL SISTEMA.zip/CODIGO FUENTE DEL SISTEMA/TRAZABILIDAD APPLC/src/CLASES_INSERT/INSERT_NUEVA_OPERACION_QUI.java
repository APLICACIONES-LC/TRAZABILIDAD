/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_INSERT;

import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class INSERT_NUEVA_OPERACION_QUI {
       /////////////////////////////////////////////conexión//////////
    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
    public boolean mensaje=false;
    public void insertar(String descripcion,String nombre){
    
     String ins = "INSERT INTO  tbl_n_operacion(str_descripcion, str_nombre_operacion) VALUES(?,?)";
                try {
                    PreparedStatement pst = cnu.prepareStatement(ins);
                   pst.setString(1,descripcion);
                   pst.setString(2, nombre);
                
                   
                    
                    int n = pst.executeUpdate();
//                    
//                   
                    if (n > 0) {
                        JOptionPane.showMessageDialog(null, "Se inserto correctamentente");
                  mensaje=true;     
                    } else {
                        JOptionPane.showMessageDialog(null, "Error, vuelva a intentarlo verifique que todos los campos\n"
                                + "estén llenos", "Sistema ", JOptionPane.ERROR_MESSAGE);
                        mensaje=false;
                    }
                    
                } catch (SQLException ex) {
                  mensaje=false;
                       JOptionPane.showMessageDialog(null, "Error, ocurrio un error imprevisto, vuelva a intentar y si el problema\n"
                               + "persiste favor de comunicarse con los especialistas de sistemas", "Sistema ", JOptionPane.ERROR_MESSAGE);
                         Logger.getLogger(INSERT_PAQUETE_A_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
}
