/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_DELETE;

import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class DELETE_USUARIO {
         Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    public boolean bandera=false;
public void eliminar_USUARIO(String id) throws SQLException{
     try {
                    String ins = "DELETE from tbl_usuario  where str_id_usuario= ? ";
                    PreparedStatement pst = cnu.prepareStatement(ins);
                    pst.setString(1, id);
                   
                   int a= pst.executeUpdate();
                   if(a>0){
          JOptionPane.showMessageDialog(null, "El usuario fue eliminado con exito", "Sistema ", JOptionPane.DEFAULT_OPTION, null);
                bandera=true;
                   }else{
      JOptionPane.showMessageDialog(null, "El usuario no pudo ser eliminado", "Sistema ", JOptionPane.ERROR_MESSAGE);  
                   }
                } catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, "No fue elimiando el usuario vuelve a intentar si el problema persiste\n"
            + "comunicate con los especialistas de sistemas", "STQH-INTERFACING ", JOptionPane.ERROR_MESSAGE);  
                    Logger.getLogger(DELETE_PROCESO.class.getName()).log(Level.SEVERE, null, ex);
                }
     cnu.close();
}    

}