/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLASES_DELETE;

import CONEXION.Conectar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author ERICK IVAN
 */
public class DELETE_CIRUGIA {
      Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    public boolean bandera=false;
public void eliminar_proceso() throws SQLException{
     try {
                    String ins = "DELETE from tbl_n_operacion  where str_id_operacion= ? ";
                    PreparedStatement pst = cnu.prepareStatement(ins);
                    pst.setString(1, Constantes.Constantes.ID_CIRUGIAS);
                   
                   int a= pst.executeUpdate();
                   if(a>0){
          JOptionPane.showMessageDialog(null, "Eliminacion exitosa", "Sistema ", JOptionPane.DEFAULT_OPTION, null);
         bandera=true;
                   }else{
      JOptionPane.showMessageDialog(null, "No se puedo eliminar", "Sistema ", JOptionPane.ERROR_MESSAGE);  
                   }
                } catch (SQLException ex) {
    JOptionPane.showMessageDialog(null, "No fue elimiando vuelve a intentar si el problema persiste\n"
            + "comunicate con los especialistas de sistemas", "Sistema ", JOptionPane.ERROR_MESSAGE);  
                    Logger.getLogger(DELETE_CIRUGIA.class.getName()).log(Level.SEVERE, null, ex);
                }
     cnu.close();
}    

}
