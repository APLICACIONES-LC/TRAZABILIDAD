/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ADMINISTRADOR_MONITORISTA;

import CLASES_UPDATE.UPDATE_OPERANDO;
import CONEXION.Conectar;
import Constantes.Constantes;
import REPORTES_PDF.Reporte_entrega;
import java.awt.Image;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.swing.ImageIcon;




/**
 *
 * @author ERICK IVAN
 */
public final class HACER_QUE extends javax.swing.JDialog {
    private static final long serialVersionUID = 1L;

 Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    
   
  
    public HACER_QUE(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
      Image icon = new ImageIcon(getClass().getResource("/img/iconfel100.png")).getImage();
        setIconImage(icon);
         int ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
       int alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;

        this.setLocation((ancho / 2) - (this.getWidth() / 2), (alto / 2) - (this.getHeight() / 2));
        
 recibe();

    }

    void recibe(){
        lbl_cantidad.setText(""+Constantes.CANTIDAD+" pz.");
        lbl_paquete1.setText(""+Constantes.NOMBRE_PAQUETE);
        lbl_identificador.setText(""+Constantes.CODIGO_DE_BARRAS);
        lbl_depa.setText(""+Constantes.DEPARTAMENTO);
        txt_instrumentos.append(""+Constantes.INCLUYE);
                   
    }
//    void consulta_tabla(){
//          String sqll = "SELECT * FROM tbl_instrumentos";
//        Statement stt;
//        try {
//            stt = cnu.createStatement();
//            ResultSet rss = stt.executeQuery(sqll);
//
//            while (rss.next()) {
//                String dato1 = rss.getString("str_id");
//                String dato2 = rss.getString("str_nombre");
//                String dato3 = rss.getString("str_esterilizado");
//               
//              
// 
//    
//  String instrumentos[] = {dato1, dato2, dato3};
//        md_paquete_instrumentos.addRow(instrumentos);
//            }
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
//                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
//                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);
//
//            Logger.getLogger(SELECT_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new org.edisoncor.gui.panel.Panel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_instrumentos = new javax.swing.JTextArea();
        lbl_cantidad = new javax.swing.JLabel();
        lbl_paquete1 = new javax.swing.JLabel();
        lbl_identificador = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        jLabel5 = new javax.swing.JLabel();
        lbl_depa = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("PAQUETE ESTERILIZADO");

        panel1.setColorPrimario(new java.awt.Color(255, 255, 255));
        panel1.setColorSecundario(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 0));
        jLabel1.setText("Cantidad:");

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 0));
        jLabel2.setText("Identificador:");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 0));
        jLabel3.setText("Nombre del paquete:");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 0));
        jLabel4.setText("Instrumentos:");

        txt_instrumentos.setEditable(false);
        txt_instrumentos.setColumns(20);
        txt_instrumentos.setRows(5);
        jScrollPane2.setViewportView(txt_instrumentos);

        lbl_cantidad.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lbl_cantidad.setText("1256987456");

        lbl_paquete1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lbl_paquete1.setText("paquete enlaze del octeto");

        lbl_identificador.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lbl_identificador.setText("1256987456");

        jButton2.setText("Ejecutar envio");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jToggleButton1.setText("Cancelar envio");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 0));
        jLabel5.setText("Departamento:");

        lbl_depa.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lbl_depa.setText("paquete enlaze del octeto");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_paquete1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_cantidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_depa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jToggleButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbl_identificador, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_cantidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_identificador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_depa))
                .addGap(18, 18, 18)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbl_paquete1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jToggleButton1)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        panel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jButton2, jToggleButton1});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

//boolean si_o_no=false;
//UPDATE_HACER_QUE UHQ=new UPDATE_HACER_QUE();
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      @SuppressWarnings("UnusedAssignment")
      String area="";
      area=txt_instrumentos.getText();
        ArrayList<String> añadir=new ArrayList<>();
        StringTokenizer token=new StringTokenizer(area,":");
        while (token.hasMoreElements()) {
      
            añadir.add(""+token.nextElement());
        }
        
         
        System.out.println(""+añadir);
        Reporte_entrega RE=new Reporte_entrega();
        RE.TABLA_LISTA=añadir;
        RE.PDF();
UPDATE_OPERANDO UO=new UPDATE_OPERANDO();
UO.update_operacion_tbl_paquete();
 this.dispose();
//
//this.hide();
//     try {
//         UHQ.metodo_commit();
//     } catch (SQLException ex) {
//         Logger.getLogger(HACER_QUE.class.getName()).log(Level.SEVERE, null, ex);
//     }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
 this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton1ActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JLabel lbl_cantidad;
    private javax.swing.JLabel lbl_depa;
    private javax.swing.JLabel lbl_identificador;
    private javax.swing.JLabel lbl_paquete1;
    private org.edisoncor.gui.panel.Panel panel1;
    private javax.swing.JTextArea txt_instrumentos;
    // End of variables declaration//GEN-END:variables
}
