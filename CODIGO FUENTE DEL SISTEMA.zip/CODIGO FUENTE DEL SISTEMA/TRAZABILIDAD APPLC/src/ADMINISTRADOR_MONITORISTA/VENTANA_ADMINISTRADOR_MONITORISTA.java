/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ADMINISTRADOR_MONITORISTA;

import ACERCADE.ACERCADE;
import ADMINISTRADOR_RAIZ.DIALOG_IMAGEN_CON_DATOS;
import ADMINISTRADOR_RAIZ.VENTANA_ADMIN_ADMIN;

import CAMBIO_DE_COLOR_CELDAS.CellRenderer;
import CLASES_DELETE.DELETE_PROCESO;
import CLASES_INSERT.INSERT_PAQUETE_A_NOTIFICACION;
import CLASES_INSERT.INSERT_PAQUETE_TERMINADO;
import CLASES_SELECT.SELECT_NOTIFICACION;
import CLASES_SELECT.SELECT_VERIFICAR_NOMBRE;
import CLASES_UPDATE.UPDATE_STOCK_INSTRUMENTOS;
import CONEXION.Conectar;
import Constantes.Constantes;
import LOGIN.LOGUEO;
import REPORTES_PDF.Reporte_comienzo;
import USUARIO.*;
//import org.fife.ui.autocomplete.AutoCompletion;
import com.mxrck.autocompleter.TextAutoCompleter;
import java.awt.Image;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


/**
 *
 * @author ERICK IVAN
 */
public final class VENTANA_ADMINISTRADOR_MONITORISTA extends javax.swing.JFrame {
    private static final long serialVersionUID = 1L;

    /////////////////////////////////////////////conexión//////////
    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////

    public DefaultTableModel md_noti;
    String[][] data1 = {};
    String[] columnas1 = {"ID", "NOMBRE", "CANTIDAD", "INCLUYE", "DEPARTAMENTO", "PRE-LAVADO", "LAVADO", "INSPECCION", "PREPARACION", "EMPAQUE", "ESTERILIZACION"};

    public DefaultTableModel md_inicial;
    String[][] data2 = {};
    String[] columnas2 = {"ID", "NOMBRE", "STOCK", "EN OPERACIÓN", "TIPO"};

    public DefaultTableModel md_paquete;
    String[][] data3 = {};
    String[] columnas3 = {"ID", "NOMBRE", "CANTIDAD"};

    public DefaultTableModel md_paquete_feliz;
    String[][] data4 = {};
    String[] columnas4 = {"ID", "NOMBRE", "INCLUYE", "DEPARTAMENTO", "CANTIDAD"};

    public DefaultTableModel md_paquete_operando;
    String[][] data5 = {};
    String[] columnas5 = {"ID", "NOMBRE", "INCLUYE", "CANTIDAD", "DEPARTAMENTO", "STATUS"};

    public VENTANA_ADMINISTRADOR_MONITORISTA() {
        initComponents();
        Image icon = new ImageIcon(getClass().getResource("/IMG/iconfel100.png")).getImage();
        setIconImage(icon);
         int ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
       int alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;

        this.setLocation((ancho / 2) - (this.getWidth() / 2), (alto / 2) - (this.getHeight() / 2));
          this.setExtendedState(MAXIMIZED_BOTH);
          
        
          
        md_noti = new DefaultTableModel(data1, columnas1);
        tbl_noti.setModel(md_noti);
        tbl_noti.getTableHeader().setReorderingAllowed(false) ;

        md_inicial = new DefaultTableModel(data2, columnas2);
        tbl_inicial.setModel(md_inicial);
          tbl_inicial.getTableHeader().setReorderingAllowed(false) ;

        md_paquete = new DefaultTableModel(data3, columnas3){
            private static final long serialVersionUID = 1L;
            @Override
    public boolean isCellEditable(int rowIndex,int columnIndex){return false;}
        };
        tbl_paquete.setModel(md_paquete);
        tbl_paquete.getTableHeader().setReorderingAllowed(false) ;
        
        md_paquete_feliz = new DefaultTableModel(data4, columnas4);
        tbl_paquete_esterilizado.setModel(md_paquete_feliz);
        tbl_paquete_esterilizado.getTableHeader().setReorderingAllowed(false) ;

        md_paquete_operando = new DefaultTableModel(data5, columnas5);
        tbl_en_operacion.setModel(md_paquete_operando);
        tbl_en_operacion.getTableHeader().setReorderingAllowed(false) ;

        tbl_inicial.getColumnModel().getColumn(0).setMaxWidth(70);
        tbl_inicial.getColumnModel().getColumn(0).setMinWidth(60);
        tbl_inicial.getColumnModel().getColumn(0).setPreferredWidth(50);
        
        tbl_inicial.getColumnModel().getColumn(1).setMaxWidth(700);
        tbl_inicial.getColumnModel().getColumn(1).setMinWidth(650);
        
         tbl_inicial.getColumnModel().getColumn(4).setMaxWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setMinWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setPreferredWidth(0);
          
        tbl_inicial.setRowHeight(45); 
          tbl_noti.setRowHeight(45);
          tbl_en_operacion.setRowHeight(45);
          tbl_paquete_esterilizado.setRowHeight(45);
         
      
        

        setCellRender(tbl_noti);

        btn_añadir.setEnabled(false);
autocompletar();
auto_cirugias();
//        hilo1.start();
    }

    public void setCellRender(JTable table) {
        Enumeration<TableColumn> en = table.getColumnModel().getColumns();
        while (en.hasMoreElements()) {
            TableColumn tc = en.nextElement();
            tc.setCellRenderer(new CellRenderer());
        }
    }
  private void autocompletar() {
     
        TextAutoCompleter textAutoCompleter = new TextAutoCompleter(txt_filtro);
        String msql = "SELECT * FROM tbl_instrumentos ";
        Statement st;
        try {      
            st = cnu.createStatement();
            ResultSet rs = st.executeQuery(msql);
            while (rs.next()) {
                textAutoCompleter.addItem(rs.getString("str_id"));
                textAutoCompleter.addItem(rs.getString("str_nombre"));

            }

        } catch (SQLException ex) {
            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }
      
      
    }
  
  void auto_cirugias(){
       TextAutoCompleter textAutoCompleter = new TextAutoCompleter(txt_filtro);
      String msql2 = "SELECT * FROM tbl_n_operacion ";
        Statement st2;
        try {      
            st2 = cnu.createStatement();
            ResultSet rs2 = st2.executeQuery(msql2);
            while (rs2.next()) {
                textAutoCompleter.addItem(rs2.getString("str_nombre_operacion"));
              

            }

        } catch (SQLException ex) {
            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }
  }
//    Thread hilo1 = new Thread() {
//        public void run() {
//
//            while (true) {
//
//          ACTUALIZAR_STATUS();
//
//              
//
//                    
//                
//                try {
//                    hilo1.sleep(2000);
//                } catch (InterruptedException ex) {
//                    Logger.getLogger(VENTANA_USUARIO.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
//        }
//
//      
//
//    };
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupo1 = new javax.swing.ButtonGroup();
        panel1 = new org.edisoncor.gui.panel.Panel();
        panelShadow1 = new org.edisoncor.gui.panel.PanelShadow();
        jPanel1 = new javax.swing.JPanel();
        btn_status = new javax.swing.JButton();
        btn_iniciar = new javax.swing.JButton();
        btn_entrega_paquete = new javax.swing.JButton();
        btn_status1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        panelShadow2 = new org.edisoncor.gui.panel.PanelShadow();
        panel3 = new org.edisoncor.gui.panel.Panel();
        txt_nombre_paquete = new org.edisoncor.gui.textField.TextFieldRectBackground();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_cantidad = new org.edisoncor.gui.textField.TextFieldRectBackground();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_nombre_departamento = new org.edisoncor.gui.textField.TextFieldRectBackground();
        btn_eliminar_armado = new javax.swing.JButton();
        btn_añadir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_paquete = new javax.swing.JTable();
        panelShadow3 = new org.edisoncor.gui.panel.PanelShadow();
        JI_FRAME_ESTERILIZACION = new javax.swing.JInternalFrame();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbl_inicial = new javax.swing.JTable();
        panel2 = new org.edisoncor.gui.panel.Panel();
        btn_activador = new javax.swing.JButton();
        txt_filtro = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        JI_FRAME_PAQUETE = new javax.swing.JInternalFrame();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_paquete_esterilizado = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        JI_FRAME_EN_OPERACION = new javax.swing.JInternalFrame();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_en_operacion = new javax.swing.JTable();
        JI_FRAME_ESTATUS = new javax.swing.JInternalFrame();
        jScrollPane7 = new javax.swing.JScrollPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tbl_noti = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("MONITORISTA ADMINISTRADOR");

        panel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panel1.setColorPrimario(new java.awt.Color(255, 255, 255));
        panel1.setColorSecundario(new java.awt.Color(255, 255, 255));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_status.setBackground(new java.awt.Color(102, 153, 255));
        btn_status.setForeground(new java.awt.Color(255, 255, 255));
        btn_status.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/bombilla.png"))); // NOI18N
        btn_status.setText("Status");
        btn_status.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 102)));
        btn_status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_statusActionPerformed(evt);
            }
        });
        jPanel1.add(btn_status, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, 130, 40));

        btn_iniciar.setBackground(new java.awt.Color(0, 204, 204));
        btn_iniciar.setForeground(new java.awt.Color(255, 255, 255));
        btn_iniciar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/idea.png"))); // NOI18N
        btn_iniciar.setText("Iniciar");
        btn_iniciar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 102)));
        btn_iniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_iniciarActionPerformed(evt);
            }
        });
        jPanel1.add(btn_iniciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 140, 40));

        btn_entrega_paquete.setBackground(new java.awt.Color(0, 204, 204));
        btn_entrega_paquete.setForeground(new java.awt.Color(255, 255, 255));
        btn_entrega_paquete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/monedas.png"))); // NOI18N
        btn_entrega_paquete.setText("Entrega de paquetes");
        btn_entrega_paquete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 102)));
        btn_entrega_paquete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_entrega_paqueteActionPerformed(evt);
            }
        });
        jPanel1.add(btn_entrega_paquete, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, 210, 40));

        btn_status1.setBackground(new java.awt.Color(0, 204, 204));
        btn_status1.setForeground(new java.awt.Color(255, 255, 255));
        btn_status1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/clasificacion.png"))); // NOI18N
        btn_status1.setText("En operación");
        btn_status1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 102)));
        btn_status1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_status1ActionPerformed(evt);
            }
        });
        jPanel1.add(btn_status1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, 170, 40));

        jButton5.setBackground(new java.awt.Color(0, 204, 204));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir ses.png"))); // NOI18N
        jButton5.setText("Cerrar Sesión");
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 102)));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, 130, 40));

        jButton6.setBackground(new java.awt.Color(0, 204, 204));
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/rompecabezas.png"))); // NOI18N
        jButton6.setText("Acerca de");
        jButton6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 102)));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 0, 130, 40));

        javax.swing.GroupLayout panelShadow1Layout = new javax.swing.GroupLayout(panelShadow1);
        panelShadow1.setLayout(panelShadow1Layout);
        panelShadow1Layout.setHorizontalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelShadow1Layout.setVerticalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelShadow1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(11, 11, 11))
        );

        panelShadow2.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 204)));
        panelShadow2.setAngle(1.0F);

        panel3.setColorPrimario(new java.awt.Color(255, 255, 255));
        panel3.setColorSecundario(new java.awt.Color(255, 255, 255));

        txt_nombre_paquete.setDescripcion("ingrese un nombre aquí");

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel1.setText("Nombre del paquete:");

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel2.setText("Cantidad total:");

        txt_cantidad.setEditable(false);
        txt_cantidad.setText("0");
        txt_cantidad.setDescripcion("");
        txt_cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cantidadActionPerformed(evt);
            }
        });

        jLabel3.setText("PZ.");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel4.setText("Nombre del departamento:");

        txt_nombre_departamento.setDescripcion("ingrese un nombre aquí");

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_nombre_paquete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txt_nombre_departamento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel3Layout.createSequentialGroup()
                        .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(panel3Layout.createSequentialGroup()
                                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txt_cantidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3))
                            .addComponent(jLabel4))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(10, 10, 10)
                .addComponent(txt_nombre_paquete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(10, 10, 10)
                .addComponent(txt_nombre_departamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(10, 10, 10)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btn_eliminar_armado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/carpeta.png"))); // NOI18N
        btn_eliminar_armado.setText("Eliminar");
        btn_eliminar_armado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminar_armadoActionPerformed(evt);
            }
        });

        btn_añadir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/aceptar.png"))); // NOI18N
        btn_añadir.setText("Aceptar");
        btn_añadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_añadirActionPerformed(evt);
            }
        });

        tbl_paquete.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbl_paquete);

        javax.swing.GroupLayout panelShadow2Layout = new javax.swing.GroupLayout(panelShadow2);
        panelShadow2.setLayout(panelShadow2Layout);
        panelShadow2Layout.setHorizontalGroup(
            panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelShadow2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(panel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelShadow2Layout.createSequentialGroup()
                        .addComponent(btn_eliminar_armado)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_añadir)))
                .addContainerGap())
        );
        panelShadow2Layout.setVerticalGroup(
            panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelShadow2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_eliminar_armado)
                    .addComponent(btn_añadir))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelShadow3.setBackground(new java.awt.Color(255, 255, 255));
        panelShadow3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 204, 204)));
        panelShadow3.setAngle(1.0F);

        JI_FRAME_ESTERILIZACION.setTitle("STOCK DE INSTRUMENTOS");
        JI_FRAME_ESTERILIZACION.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_instrumentacion.png"))); // NOI18N
        JI_FRAME_ESTERILIZACION.setVisible(false);

        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.LINE_AXIS));

        tbl_inicial.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        tbl_inicial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"<HTML> HOLA<br/>si tu<html>", null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_inicial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_inicialMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tbl_inicial);

        jPanel2.add(jScrollPane5);

        jScrollPane2.setViewportView(jPanel2);

        panel2.setColorPrimario(new java.awt.Color(255, 255, 255));
        panel2.setColorSecundario(new java.awt.Color(255, 255, 255));

        btn_activador.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/encender.png"))); // NOI18N
        btn_activador.setText("Activar ingreso.");
        btn_activador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_activadorActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/buscando.png"))); // NOI18N
        jButton2.setText("Buscar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel5.setText("Buscar por filtro");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                    .addComponent(txt_filtro))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_activador)
                .addContainerGap())
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_activador)
                    .addComponent(txt_filtro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        javax.swing.GroupLayout JI_FRAME_ESTERILIZACIONLayout = new javax.swing.GroupLayout(JI_FRAME_ESTERILIZACION.getContentPane());
        JI_FRAME_ESTERILIZACION.getContentPane().setLayout(JI_FRAME_ESTERILIZACIONLayout);
        JI_FRAME_ESTERILIZACIONLayout.setHorizontalGroup(
            JI_FRAME_ESTERILIZACIONLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane2)
        );
        JI_FRAME_ESTERILIZACIONLayout.setVerticalGroup(
            JI_FRAME_ESTERILIZACIONLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JI_FRAME_ESTERILIZACIONLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        JI_FRAME_PAQUETE.setTitle("PAQUETES");
        JI_FRAME_PAQUETE.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_paquetes.png"))); // NOI18N
        JI_FRAME_PAQUETE.setVisible(false);

        tbl_paquete_esterilizado.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        tbl_paquete_esterilizado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_paquete_esterilizado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_paquete_esterilizadoMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_paquete_esterilizado);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/envio.png"))); // NOI18N
        jButton1.setText("Crear paquete");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addContainerGap())
        );

        javax.swing.GroupLayout JI_FRAME_PAQUETELayout = new javax.swing.GroupLayout(JI_FRAME_PAQUETE.getContentPane());
        JI_FRAME_PAQUETE.getContentPane().setLayout(JI_FRAME_PAQUETELayout);
        JI_FRAME_PAQUETELayout.setHorizontalGroup(
            JI_FRAME_PAQUETELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        JI_FRAME_PAQUETELayout.setVerticalGroup(
            JI_FRAME_PAQUETELayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        JI_FRAME_EN_OPERACION.setTitle("INSTRUMENTOS EN OPERACIÓN");
        JI_FRAME_EN_OPERACION.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_en_operacion.png"))); // NOI18N
        JI_FRAME_EN_OPERACION.setVisible(false);

        tbl_en_operacion.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        tbl_en_operacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_en_operacion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_en_operacionMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_en_operacion);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 409, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout JI_FRAME_EN_OPERACIONLayout = new javax.swing.GroupLayout(JI_FRAME_EN_OPERACION.getContentPane());
        JI_FRAME_EN_OPERACION.getContentPane().setLayout(JI_FRAME_EN_OPERACIONLayout);
        JI_FRAME_EN_OPERACIONLayout.setHorizontalGroup(
            JI_FRAME_EN_OPERACIONLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        JI_FRAME_EN_OPERACIONLayout.setVerticalGroup(
            JI_FRAME_EN_OPERACIONLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        JI_FRAME_ESTATUS.setTitle("ESTATUS DE LOS PROCESOS");
        JI_FRAME_ESTATUS.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_estatus.png"))); // NOI18N
        JI_FRAME_ESTATUS.setVisible(true);

        jScrollPane7.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jPanel5.setLayout(new javax.swing.BoxLayout(jPanel5, javax.swing.BoxLayout.LINE_AXIS));

        tbl_noti.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        tbl_noti.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_noti.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_notiMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(tbl_noti);

        jPanel5.add(jScrollPane9);

        jScrollPane7.setViewportView(jPanel5);

        javax.swing.GroupLayout JI_FRAME_ESTATUSLayout = new javax.swing.GroupLayout(JI_FRAME_ESTATUS.getContentPane());
        JI_FRAME_ESTATUS.getContentPane().setLayout(JI_FRAME_ESTATUSLayout);
        JI_FRAME_ESTATUSLayout.setHorizontalGroup(
            JI_FRAME_ESTATUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 527, Short.MAX_VALUE)
        );
        JI_FRAME_ESTATUSLayout.setVerticalGroup(
            JI_FRAME_ESTATUSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 530, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelShadow3Layout = new javax.swing.GroupLayout(panelShadow3);
        panelShadow3.setLayout(panelShadow3Layout);
        panelShadow3Layout.setHorizontalGroup(
            panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JI_FRAME_PAQUETE, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JI_FRAME_ESTERILIZACION, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(JI_FRAME_EN_OPERACION, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(JI_FRAME_ESTATUS)
                    .addContainerGap()))
        );
        panelShadow3Layout.setVerticalGroup(
            panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JI_FRAME_PAQUETE, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(JI_FRAME_ESTERILIZACION, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelShadow3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(JI_FRAME_EN_OPERACION, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelShadow3Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(JI_FRAME_ESTATUS)
                    .addContainerGap()))
        );

        try {
            JI_FRAME_ESTERILIZACION.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            JI_FRAME_PAQUETE.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            JI_FRAME_EN_OPERACION.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            JI_FRAME_ESTATUS.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelShadow1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(panelShadow2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19)
                        .addComponent(panelShadow3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addComponent(panelShadow1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelShadow2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelShadow3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbl_inicialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_inicialMouseClicked
if(activador==true){     
        Agregar AG = new Agregar(this, true);
        AG.setLocation(500,100);
        AG.setVisible(true);
        int recibe_numero = Integer.parseInt(AG.cantidad);
        System.out.println("---" + recibe_numero);
        String cantidad = "" + recibe_numero;
if(AG.bandera==true){
        //los dos renglones de codigo funcionan para obtener el datoo de un jtable 
        int contador = tbl_inicial.getSelectedRow();//lee el N° de columna  que seleccionamos
        String dato1_id = (String) tbl_inicial.getValueAt(contador, 0);//obtiene el valor de una celda 
        String dato2_nombre = (String) tbl_inicial.getValueAt(contador, 1);//obtiene el valor de una celda 
        int dato3_cantidad = Integer.parseInt((String) tbl_inicial.getValueAt(contador, 2));//obtiene el valor de una celda 

        if (recibe_numero > dato3_cantidad) {
            JOptionPane.showMessageDialog(null, "No puede ser mayor la cantidad que el Stock intenta de nuevo", "ERROR", JOptionPane.ERROR_MESSAGE);
        } else {

            String incluir[] = {dato1_id, dato2_nombre, cantidad};//preparamos las cadenas para añadirlas en otras tablas
            md_paquete.addRow(incluir);//lo añadimos a la tabla

            int suma_cantidad = Integer.parseInt(txt_cantidad.getText());
            suma_cantidad = suma_cantidad + recibe_numero;
            txt_cantidad.setText("" + suma_cantidad);
            btn_añadir.setEnabled(true);
        }
}
}else{
   @SuppressWarnings("UnusedAssignment")
   String dato1_id ="";
        int contador = tbl_inicial.getSelectedRow();//lee el N° de columna  que seleccionamos
        dato1_id = (String) tbl_inicial.getValueAt(contador, 0);//obtiene el valor de una celda 
        
        Constantes.ID_INSTRUMENTO_IMAGEN=dato1_id;
        
        DIALOG_IMAGEN_CON_DATOS DICD=new DIALOG_IMAGEN_CON_DATOS(this, true);
        DICD.setVisible(true);
}
    }//GEN-LAST:event_tbl_inicialMouseClicked

    private void btn_iniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_iniciarActionPerformed
     actualiza_inicio();

    }//GEN-LAST:event_btn_iniciarActionPerformed

    private void btn_statusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_statusActionPerformed
     
        ACTUALIZAR_STATUS();
   cambio_ventana(false, false, true, false);
    }//GEN-LAST:event_btn_statusActionPerformed

    private void txt_cantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_cantidadActionPerformed

    @SuppressWarnings("UnusedAssignment")
    private void btn_eliminar_armadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminar_armadoActionPerformed

        if (tbl_paquete.getRowCount() > 0) {

            try {
              int    contador = tbl_paquete.getSelectedRow();//lee el N° de columna  que seleccionamos
              String  dato2_cantidad = (String) tbl_paquete.getValueAt(contador, 2);//obtiene el valor de una celda 

                   int restar_cantidad = Integer.parseInt(dato2_cantidad);
                int resta_cantidad = Integer.parseInt(txt_cantidad.getText());
                resta_cantidad = resta_cantidad - restar_cantidad;
                txt_cantidad.setText("" + resta_cantidad);
                
                   DefaultTableModel ACTIVO = (DefaultTableModel) tbl_paquete.getModel();
                ACTIVO.removeRow(tbl_paquete.getSelectedRow());
                tbl_paquete.addRowSelectionInterval(0, 0);
                ACTIVO = null;
               
                
             
                
          
                
             

            } catch (Exception e) {
                if (tbl_paquete.getRowCount() > 0) {
                    JOptionPane.showMessageDialog(null, "Favor de seleccionar el Instrumento a quitar", "Sistema (APLICACIONES LC)", JOptionPane.WARNING_MESSAGE);
                }
            }    //  System.out.println("valor= " + contador + "  --cantid: " + dato2_cantidad);
                
        } else {
            JOptionPane.showMessageDialog(tbl_paquete, "No hay Instrumentos seleccionados", "Sistema (APLICACIONES LC)", JOptionPane.WARNING_MESSAGE);

        }      
    }//GEN-LAST:event_btn_eliminar_armadoActionPerformed

    private void btn_añadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_añadirActionPerformed

        String Nombre_paquete = txt_nombre_paquete.getText();
        String Nombre_departamento = txt_nombre_departamento.getText();

        ArrayList<String> TABLA_instrumentos = new ArrayList<>();
        ArrayList<String> TABLA_pdf_instrumentos = new  ArrayList<>();
        boolean bandera = true;
        for (int i = 0; i < tbl_paquete.getRowCount(); i++) {
            System.out.println("vuelta: " + i);

            if (tbl_paquete.getValueAt(i, 2).toString().equals("0")) {
                JOptionPane.showMessageDialog(null, "Se encontro un error ninguna cantidad puede ser 0", "Error", JOptionPane.ERROR_MESSAGE);
                bandera = false;
                break;
            }

            TABLA_instrumentos.add(tbl_paquete.getValueAt(i, 0).toString() + " : " + tbl_paquete.getValueAt(i, 1).toString() + " : " + tbl_paquete.getValueAt(i, 2).toString() + " pz:");
            TABLA_pdf_instrumentos.add(tbl_paquete.getValueAt(i, 0).toString());
            TABLA_pdf_instrumentos.add(tbl_paquete.getValueAt(i, 1).toString());
            TABLA_pdf_instrumentos.add(tbl_paquete.getValueAt(i, 2).toString() + " pz.");

        }

        if (TABLA_instrumentos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay nada que ingresar", "Error", JOptionPane.ERROR_MESSAGE);
            bandera = false;
        }

        if (bandera == true) {
            int cantidad = Integer.parseInt(txt_cantidad.getText());
            Constantes.CANTIDAD=""+cantidad;
            if (!Nombre_paquete.equals("")) {

                SELECT_VERIFICAR_NOMBRE SVN = new SELECT_VERIFICAR_NOMBRE();
                SVN.notificacion(Nombre_paquete);
                if (SVN.bandera == false) {
                    JOptionPane.showMessageDialog(null, "Lo lamentamos no puedes nombrar este paquete con un nombre que ya existe en la tabla", "Información", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    Constantes.DEPARTAMENTO=Nombre_departamento;
                    INSERT_PAQUETE_A_NOTIFICACION IPN = new INSERT_PAQUETE_A_NOTIFICACION();
                    IPN.insertar(Nombre_paquete, cantidad, TABLA_instrumentos, Nombre_departamento);
                    if (IPN.mensaje = true) {
                        txt_cantidad.setText("0");
                        txt_nombre_paquete.setText("");
                        txt_nombre_departamento.setText("");
                        for (int i = 0; i < tbl_paquete.getRowCount(); i++) {
                            System.out.println("vuelta: " + i);

                            String dato1_nombre = (String) tbl_paquete.getValueAt(i, 0);//obtiene el valor de una celda 
                            int dato2_cantidad = Integer.parseInt((String) tbl_paquete.getValueAt(i, 2));//obtiene el valor de una celda 
                            System.out.println("-------" + dato1_nombre + "----------" + dato2_cantidad);
                            UPDATE_STOCK_INSTRUMENTOS USI = new UPDATE_STOCK_INSTRUMENTOS();
                            USI.update_instrumentos(dato1_nombre, dato2_cantidad);
                        }
                        
                        Reporte_comienzo RC = new Reporte_comienzo();
                        RC.TABLA_LISTA = TABLA_pdf_instrumentos;
                        RC.PDF();

                        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_paquete.getModel();
                        for (int i = 0; i < tbl_paquete.getRowCount(); i++) {
                            ACTIVO.removeRow(i);
                            i -= 1;
                        }

                        mostrar_noti_uno_x_uno();

                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Te falta ingresar un nombre al paquete", "Información", JOptionPane.INFORMATION_MESSAGE);
            }

        }

    }//GEN-LAST:event_btn_añadirActionPerformed

    private void btn_entrega_paqueteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_entrega_paqueteActionPerformed
      metodo_btn_entrega_paquete();
    }//GEN-LAST:event_btn_entrega_paqueteActionPerformed

    private void tbl_paquete_esterilizadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_paquete_esterilizadoMouseClicked

        int contador = tbl_paquete_esterilizado.getSelectedRow();//lee el N° de columna  que seleccionamos
        String dato1_id = (String) tbl_paquete_esterilizado.getValueAt(contador, 0);//obtiene el valor de una celda 
        String dato2_nombre = (String) tbl_paquete_esterilizado.getValueAt(contador, 1);//obtiene el valor de una celda 
        String dato3_incluye = (String) tbl_paquete_esterilizado.getValueAt(contador, 2);//obtiene el valor de una celda 
        String dato5_departamento = (String) tbl_paquete_esterilizado.getValueAt(contador, 3);//obtiene el valor de una celda 
        String dato4_cantidad = (String) tbl_paquete_esterilizado.getValueAt(contador, 4);//obtiene el valor de una celda 
        System.out.println("id: " + dato1_id + " nombre: " + dato2_nombre + " incluye: " + dato3_incluye + "departamento: " + dato5_departamento + " cantidad: " + dato4_cantidad);

        if (dato3_incluye.contains(",")) {
            dato3_incluye = dato3_incluye.replace("[", "");
            dato3_incluye = dato3_incluye.replace("]", "\n");
            dato3_incluye = dato3_incluye.replace(",", "\n");
        }
        Constantes.CODIGO_DE_BARRAS = dato1_id;
        Constantes.NOMBRE_PAQUETE = dato2_nombre;
        Constantes.INCLUYE = dato3_incluye;
        Constantes.CANTIDAD = dato4_cantidad;
        Constantes.DEPARTAMENTO = dato5_departamento;
//HQ.identificador=dato1_id;
//HQ.nombre="hola a todos";//dato2_nombre;
//HQ.incluye=dato3_incluye;
//HQ.cantidad=Integer.parseInt(dato4_cantidad);
        HACER_QUE HQ = new HACER_QUE(this, true);
        HQ.setVisible(true);
        System.out.println(Constantes.ID + " "
                + Constantes.NOMBRE_PAQUETE + " "
                + Constantes.INCLUYE + " "
                + Constantes.CANTIDAD);
metodo_btn_entrega_paquete();

    }//GEN-LAST:event_tbl_paquete_esterilizadoMouseClicked

    private void btn_status1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_status1ActionPerformed
    metodo_boton_status();

    }//GEN-LAST:event_btn_status1ActionPerformed

    private void tbl_en_operacionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_en_operacionMouseClicked
        int contador = tbl_en_operacion.getSelectedRow();//lee el N° de columna  que seleccionamos
        String dato1_id = (String) tbl_en_operacion.getValueAt(contador, 0);//obtiene el valor de una celda 
        String dato2_nombre = (String) tbl_en_operacion.getValueAt(contador, 1);//obtiene el valor de una celda 
        String dato3_incluye = (String) tbl_en_operacion.getValueAt(contador, 2);//obtiene el valor de una celda 
        String dato4_cantidad = (String) tbl_en_operacion.getValueAt(contador, 3);//obtiene el valor de una celda 
        String dato5_departamento = (String) tbl_en_operacion.getValueAt(contador, 4);//obtiene el valor de una celda 
      
        System.out.println("id: " + dato1_id + " nombre: " + dato2_nombre + " incluye: " + dato3_incluye + "departamento: " + dato5_departamento + " cantidad: " + dato4_cantidad);

        if (dato3_incluye.contains("[")) {
            dato3_incluye = dato3_incluye.replace("[", "");
            dato3_incluye = dato3_incluye.replace("]", "\n");
            dato3_incluye = dato3_incluye.replace(",", "\n");
        }
        Constantes.CODIGO_DE_BARRAS = dato1_id;
        Constantes.NOMBRE_PAQUETE = dato2_nombre;
        Constantes.INCLUYE = dato3_incluye;
        Constantes.CANTIDAD = dato4_cantidad;
        Constantes.DEPARTAMENTO = dato5_departamento;

        DEVOLUCION DE = new DEVOLUCION(this, true);
        DE.setVisible(true);
       metodo_boton_status();

    }//GEN-LAST:event_tbl_en_operacionMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
actualiza_inicio();
    }//GEN-LAST:event_jButton1ActionPerformed

    @SuppressWarnings("UnusedAssignment")
    private void tbl_notiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_notiMouseClicked
            if (tbl_noti.getRowCount() > 0) {

            try {
        int contador = tbl_noti.getSelectedRow();//lee el N° de columna  que seleccionamos
        String dato1_id = (String) tbl_noti.getValueAt(contador, 0);//obtiene el valor de una celda 
        String dato2_nombre = (String) tbl_noti.getValueAt(contador, 1);//obtiene el valor de una celda 
        String dato3_cantidad = (String) tbl_noti.getValueAt(contador, 2);//obtiene el valor de una celda 
        String dato4_incluye = (String) tbl_noti.getValueAt(contador, 3);//obtiene el valor de una celda
        String dato5_departamento = (String) tbl_noti.getValueAt(contador, 4);//obtiene el valor de una celda
        String dato6_proceso1 = (String) tbl_noti.getValueAt(contador, 5);//obtiene el valor de una celda
        String dato7_proceso2 = (String) tbl_noti.getValueAt(contador, 6);//obtiene el valor de una celda
        String dato8_proceso3 = (String) tbl_noti.getValueAt(contador, 7);//obtiene el valor de una celda
        String dato9_proceso4 = (String) tbl_noti.getValueAt(contador, 8);//obtiene el valor de una celda
        String dato10_proceso5 = (String) tbl_noti.getValueAt(contador, 9);//obtiene el valor de una celda
        String dato11_proceso6 = (String) tbl_noti.getValueAt(contador, 10);//obtiene el valor de una celda

        if (dato6_proceso1.equals("aprobado") && dato7_proceso2.equals("aprobado") && dato8_proceso3.equals("aprobado") && dato9_proceso4.equals("aprobado")
                && dato10_proceso5.equals("aprobado") && dato11_proceso6.equals("aprobado")) {
            JOptionPane.showMessageDialog(null, "Aprobado con exito sera movido a entrega de paquetes");

            INSERT_PAQUETE_TERMINADO IPT = new INSERT_PAQUETE_TERMINADO();
            IPT.insertar(dato1_id, dato2_nombre, dato4_incluye, dato3_cantidad, dato5_departamento);

            if (IPT.mensaje == true) {

                DELETE_PROCESO DP = new DELETE_PROCESO();
                try {
                    DP.eliminar_proceso(dato1_id);

                    DefaultTableModel ACTIVO = (DefaultTableModel) tbl_noti.getModel();
                    ACTIVO.removeRow(tbl_noti.getSelectedRow());
                    tbl_noti.addRowSelectionInterval(0, 0);
                    ACTIVO = null;
                } catch (SQLException ex) {
                    Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Esté instrumento aun no termina sus procesos", "Error", JOptionPane.ERROR_MESSAGE);
        }
        } catch (Exception e) {
                if (tbl_noti.getRowCount() > 0) {
                    JOptionPane.showMessageDialog(null, "Favor de seleccionar el Instrumento a quitar", "Sistema (APLICACIONES LC)", JOptionPane.WARNING_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(tbl_noti, "No hay Instrumentos seleccionados", "Sistema (APLICACIONES LC)", JOptionPane.WARNING_MESSAGE);

        }


    }//GEN-LAST:event_tbl_notiMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String recibe = txt_filtro.getText();
        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_inicial.getModel();
        for (int i = 0; i < tbl_inicial.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_instrumentos ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_stock");
                String dato4 = rss.getString("str_en_operacion");
                String dato5 = rss.getString("str_id_operacion");
                select_nombre_operaciones(dato5);
                if (dato1.contains(recibe) || dato2.contains(recibe) || obtiene_nombre.contains(recibe)) {
                    String instrumentos[] = {dato1, dato2, dato3, dato4, obtiene_nombre};
                    md_inicial.addRow(instrumentos);
                }
                tbl_inicial.getColumnModel().getColumn(4).setMaxWidth(300);
                tbl_inicial.getColumnModel().getColumn(4).setMinWidth(300);
                tbl_inicial.getColumnModel().getColumn(4).setPreferredWidth(300);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Existe un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_jButton2ActionPerformed
boolean activador= false;
    private void btn_activadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_activadorActionPerformed
  if(activador==false){
  btn_activador.setText("Desactivar ingreso");
  
  btn_activador.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/apagar.png")));
      activador=true;
  }else{
      btn_activador.setText("Activar ingreso");
      btn_activador.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/encender.png")));
      activador=false;
  }
    }//GEN-LAST:event_btn_activadorActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
if(Constantes.VENTANAS==true){
    JOptionPane.showMessageDialog(null, "ESTAS COMO ADMINISTRADOR VISOR ESTA INTERFAZ SERA CERRADA","INFORMACION",JOptionPane.INFORMATION_MESSAGE);
this.dispose();
}else{
       Constantes.ID="";
        Constantes.CANTIDAD="";
        Constantes.NOMBRE_PAQUETE="";
        Constantes.ID_USUARIO="";
        Constantes.ID_TIPO_USUARIO="";
        Constantes.ID_NOMBRE_USUARIO="";
        Constantes.CODIGO_DE_BARRAS="";
        Constantes.INCLUYE="";
        Constantes.DEPARTAMENTO="";
        Constantes.ENVIAR_A="";
        Constantes.ULTIMO_DIGITO="";
        Constantes.ID_INSTRUMENTOS="";
        Constantes.ID_CIRUGIAS="";
        Constantes.DIRECCION_PDF="";
        Constantes.ID_INSTRUMENTO_IMAGEN="";
  this.dispose();
  LOGUEO LO=new LOGUEO();
  LO.setVisible(true);
}   
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
     new ACERCADE(this,true).setVisible(true);
    }//GEN-LAST:event_jButton6ActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JInternalFrame JI_FRAME_EN_OPERACION;
    private javax.swing.JInternalFrame JI_FRAME_ESTATUS;
    private javax.swing.JInternalFrame JI_FRAME_ESTERILIZACION;
    private javax.swing.JInternalFrame JI_FRAME_PAQUETE;
    private javax.swing.JButton btn_activador;
    private javax.swing.JButton btn_añadir;
    private javax.swing.JButton btn_eliminar_armado;
    private javax.swing.JButton btn_entrega_paquete;
    private javax.swing.JButton btn_iniciar;
    private javax.swing.JButton btn_status;
    private javax.swing.JButton btn_status1;
    private javax.swing.ButtonGroup grupo1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane9;
    private org.edisoncor.gui.panel.Panel panel1;
    private org.edisoncor.gui.panel.Panel panel2;
    private org.edisoncor.gui.panel.Panel panel3;
    private org.edisoncor.gui.panel.PanelShadow panelShadow1;
    private org.edisoncor.gui.panel.PanelShadow panelShadow2;
    private org.edisoncor.gui.panel.PanelShadow panelShadow3;
    private javax.swing.JTable tbl_en_operacion;
    private javax.swing.JTable tbl_inicial;
    public javax.swing.JTable tbl_noti;
    private javax.swing.JTable tbl_paquete;
    private javax.swing.JTable tbl_paquete_esterilizado;
    private org.edisoncor.gui.textField.TextFieldRectBackground txt_cantidad;
    private javax.swing.JTextField txt_filtro;
    private org.edisoncor.gui.textField.TextFieldRectBackground txt_nombre_departamento;
    private org.edisoncor.gui.textField.TextFieldRectBackground txt_nombre_paquete;
    // End of variables declaration//GEN-END:variables

    void mostrar_noti_uno_x_uno() {
        //   DefaultTableModel ACTIVO = (DefaultTableModel) tbl_noti.getModel();
//        for (int i = 0; i < tbl_noti.getRowCount(); i++) {
//            ACTIVO.removeRow(i);
//            i -= 1;
//        }
        SELECT_NOTIFICACION SN = new SELECT_NOTIFICACION();
        SN.notificacion();

        String instrumentos[] = {SN.dato1, SN.dato2, SN.dato3, SN.dato4, SN.dato5, SN.dato6, SN.dato7, SN.dato8, SN.dato9, SN.dato10};
        md_noti.addRow(instrumentos);

    }

    private void ACTUALIZAR_STATUS() {

        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_noti.getModel();
        for (int i = 0; i < tbl_noti.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_proceso ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_cantidad");
                String dato4 = rss.getString("str_incluye");
                String dato5 = rss.getString("str_departamento");
                String dato6 = rss.getString("str_proceso1");
                String dato7 = rss.getString("str_proceso2");
                String dato8 = rss.getString("str_proceso3");
                String dato9 = rss.getString("str_proceso4");
                String dato10 = rss.getString("str_proceso5");
                String dato11 = rss.getString("str_proceso6");

                String instrumentos[] = {dato1, dato2, dato3, dato4, dato5, dato6, dato7, dato8, dato9, dato10, dato11};
                md_noti.addRow(instrumentos);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    String obtiene_nombre = "";

    private void select_nombre_operaciones(String dato5) {
        String sqll = "SELECT * FROM tbl_n_operacion where str_id_operacion='" + dato5 + "'";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {

                obtiene_nombre = rss.getString("str_nombre_operacion");

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Existe un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "STQH-INTERFACING", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void metodo_boton_status() {
     cambio_ventana(false, false, false, true);

        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_en_operacion.getModel();
        for (int i = 0; i < tbl_en_operacion.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_paquete where str_operacion='operando'";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id_paquete");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_incluye");
                String dato4 = rss.getString("str_cantidad");
                String dato5 = rss.getString("str_departamento");
                String dato6 = rss.getString("str_operacion");

                String instrumentos[] = {dato1, dato2, dato3, dato4, dato5, dato6};
                md_paquete_operando.addRow(instrumentos);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void metodo_btn_entrega_paquete() {
  cambio_ventana(false, true, false, false);
        btn_añadir.setEnabled(false);
        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_paquete_esterilizado.getModel();
        for (int i = 0; i < tbl_paquete_esterilizado.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_paquete where str_operacion='sin operacion'";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id_paquete");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_incluye");
                String dato4 = rss.getString("str_departamento");
                String dato5 = rss.getString("str_cantidad");

                String instrumentos[] = {dato1, dato2, dato3, dato4, dato5};
                md_paquete_feliz.addRow(instrumentos);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    private void cambio_ventana(boolean a,boolean b,boolean c,boolean d){
        
        if(a==true){
          JI_FRAME_ESTERILIZACION.setVisible(a);  
         btn_iniciar.setBackground(new java.awt.Color(102,153,255));
   
        }else{
               btn_iniciar.setBackground(new java.awt.Color(0,204,204));
          JI_FRAME_ESTERILIZACION.hide();
        }
        
         if(b==true){
         JI_FRAME_PAQUETE.setVisible(b); 
         btn_entrega_paquete.setBackground(new java.awt.Color(102,153,255));
        }else{
             btn_entrega_paquete.setBackground(new java.awt.Color(0,204,204));
         JI_FRAME_PAQUETE.hide();
        }
         
          if(c==true){
          JI_FRAME_ESTATUS.setVisible(c);  
          btn_status.setBackground(new java.awt.Color(102,153,255));
        }else{
              btn_status.setBackground(new java.awt.Color(0,204,204));
            JI_FRAME_ESTATUS.hide();
        }
          
          
           if(d==true){
           JI_FRAME_EN_OPERACION.setVisible(d);
           btn_status1.setBackground(new java.awt.Color(102,153,255));
        }else{
               btn_status1.setBackground(new java.awt.Color(0,204,204));
            JI_FRAME_EN_OPERACION.hide();
        }
        
        
         
       
        
    }

    private void actualiza_inicio() {
          cambio_ventana(true, false, false, false);
        btn_iniciar.setText("Actualizar");
        
        tbl_inicial.getColumnModel().getColumn(4).setMaxWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setMinWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setPreferredWidth(0);
        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_inicial.getModel();
        for (int i = 0; i < tbl_inicial.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_instrumentos ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_stock");
                String dato4 = rss.getString("str_en_operacion");

                String instrumentos[] = {dato1, dato2, dato3, dato4};
                md_inicial.addRow(instrumentos);

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Existe un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
