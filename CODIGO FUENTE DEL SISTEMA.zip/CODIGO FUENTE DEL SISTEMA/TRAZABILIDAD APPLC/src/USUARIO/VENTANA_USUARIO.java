/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package USUARIO;

import CAMBIO_DE_COLOR_CELDAS.CellRenderer;
import CLASES_UPDATE.UPDATE_PROCESOS;
import CONEXION.Conectar;
import Constantes.Constantes;
import LOGIN.LOGUEO;

import REPORTES_PDF.Reporte_code_barras;
import java.awt.Event;
import java.awt.Image;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


/**
 *
 * @author ERICK IVAN
 */
public final class VENTANA_USUARIO extends javax.swing.JFrame {
    private static final long serialVersionUID = 1L;

    
    
    /////////////////////////////////////////////conexión//////////

    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
//    JFreeChart chart;
// DefaultCategoryDataset line_chart_dataset = new DefaultCategoryDataset();
//   ArrayList<Double> TEMP = new <Double> ArrayList();
//   ArrayList<Double> PASC = new <Double> ArrayList();
   byte h1 = 0;
   byte tiempo_espera = 60;
   double temperatura=0, pascal=0;
   String tiempo="";
    
    /////////////////////////////////////////////////////////
    public DefaultTableModel md_noti;
    String[][] data1 = {};
    String[] columnas1 = {"ID", "NOMBRE", "CANTIDAD", "INCLUYE", "DEPARTAMENTO", "PRE-LAVADO", "LAVADO", "INSPECCION", "PREPARACION","EMPAQUE","ESTERILIZACION"};

    public VENTANA_USUARIO() {
        initComponents();
        Image icon = new ImageIcon(getClass().getResource("/IMG/iconfel100.png")).getImage();
        setIconImage(icon);
          this.setExtendedState(MAXIMIZED_BOTH);
        md_noti = new DefaultTableModel(data1, columnas1){
            private static final long serialVersionUID = 1L;
            @Override
    public boolean isCellEditable(int rowIndex,int columnIndex){return false;}
        };
        tbl_noti.setModel(md_noti);
        setCellRender(tbl_noti);
        txt_codigo_de_barras.requestFocus();
        tbl_noti.setRowHeight(45);
        tbl_noti.getTableHeader().setReorderingAllowed(false) ;
        lbl_me.setText("Identificate con tu QR");
//       hilo1.start();
//        hilo1.suspend();
    }

    public void setCellRender(JTable table) {
        Enumeration<TableColumn> en = table.getColumnModel().getColumns();
        while (en.hasMoreElements()) {
            TableColumn tc = en.nextElement();
            tc.setCellRenderer(new CellRenderer());
        }
    }

    static boolean verdad = false;
   
    
//    Thread hilo1 = new Thread() {
//        public void run() {
//
//            while (true) {
//if(verdad==false){
//    lbl_me.setText("Identificate con tu QR");
//}
//               // System.out.println("" + verdad);
////mensaje que muestra si el usuario esta registrado cada tiempo
//                CODIGO_DE_BARRAS = txt_codigo_de_barras.getText();
//                notificacion();
//                if (CODIGO_DE_BARRAS.equals(dato1_usuario) && verdad == false) {
//                    verdad = true;
//                    dato1_usuario = "(5)";
//                    txt_codigo_de_barras.setText("");
//                }
//
//                if (verdad == true) {
//                     lbl_me.setText("Ingresa el codigo de barras del paquete"); 
//                    if (CODIGO_DE_BARRAS.length() == 13) {
//
////                        int ult = CODIGO_DE_BARRAS.length();
////                        String ultimo = CODIGO_DE_BARRAS.substring(ult - 1);
////                        System.out.println("cero");
////                        if (CODIGO_DE_BARRAS.substring(ult - 1).equals("7")) {
//                            System.out.println("resultado: " + CODIGO_DE_BARRAS + "    ultimo: " );
//                          
//                           LEER_CODIGO(CODIGO_DE_BARRAS);
//                            txt_codigo_de_barras.setText("");
//                            verdad = false;
////                        }
//
//                    }
//                }
//                try {
//                    hilo1.sleep(1000);
//                } catch (InterruptedException ex) {
//                    Logger.getLogger(VENTANA_USUARIO.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            }
//        }
//   };
    
  private void LEER_CODIGO(String CODIGO_DE_BARRAS) {
      Reporte_code_barras RCB=new Reporte_code_barras();
      String sqll = "SELECT * FROM tbl_proceso where str_id='" + CODIGO_DE_BARRAS + "'";
         Statement stt;
         try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                Constantes.NOMBRE_PAQUETE= rss.getString("str_nombre");
                Constantes.DEPARTAMENTO= rss.getString("str_departamento");
                String str_proceso1 = rss.getString("str_proceso1");
                 String str_proceso2 = rss.getString("str_proceso2");
                  String str_proceso3 = rss.getString("str_proceso3");
                   String str_proceso4 = rss.getString("str_proceso4");
                    String str_proceso5 = rss.getString("str_proceso5");
                     String str_proceso6 = rss.getString("str_proceso6");
                     Constantes.CODIGO_DE_BARRAS=CODIGO_DE_BARRAS;
//////////proceso1
              if(str_proceso1.equals("esperando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos("procesando", str_proceso2, str_proceso3, str_proceso4,str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
//                  Constantes.ENVIAR_A="Prelavado: procesando";
//                  RCB.PDF();
//                  txt_area_log.append("Usuario: "+dato2_usuario_nombre+" autorizo \n"+CODIGO_DE_BARRAS+"--> pre-lavado--->\n procesando\n\n");
              }  if(str_proceso1.equals("procesando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos("aprobado", str_proceso2, str_proceso3, str_proceso4,str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
                   Constantes.ENVIAR_A="Prelavado aprobado\n Enviar a: Lavado";
                  RCB.PDF();
                 
//                   txt_area_log.append("Usuario: "+dato2_usuario_nombre+" autorizo \n"+CODIGO_DE_BARRAS+"--> pre-lavado--->\n aprobado\n\n");
              }  
             /////proceso2//////////////////////////////////
               if(str_proceso1.equals("aprobado")&&str_proceso2.equals("esperando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, "procesando", str_proceso3, str_proceso4,str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
//                  Constantes.ENVIAR_A="Lavado: procesando";
//                  RCB.PDF();
//                  txt_area_log.append("Usuario: "+dato2_usuario_nombre+" autorizo \n"+CODIGO_DE_BARRAS+"--> lavado--->\n procesando\n\n");
              }  if(str_proceso1.equals("aprobado")&&str_proceso2.equals("procesando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, "aprobado", str_proceso3, str_proceso4,str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
                  Constantes.ENVIAR_A="Lavado: aprobado\n Enviar a: Inspección";
                  RCB.PDF();
//                     txt_area_log.append("Usuario: "+dato2_usuario_nombre+" autorizo \n"+CODIGO_DE_BARRAS+"--> lavado--->\n aprobado\n\n");
              }
               ///////////proceso3////////////////////////////
               if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("esperando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, str_proceso2, "procesando", str_proceso4,str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
//                  Constantes.ENVIAR_A="Inspección: procesando";
//                  RCB.PDF();
              }  if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("procesando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, str_proceso2, "aprobado", str_proceso4,str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
                  Constantes.ENVIAR_A="Inspeccion: aprobado\nEnviar a: Preparación";
                  RCB.PDF();
              }
                //////////////////proceso4/////////////////////
               if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("aprobado")&&str_proceso4.equals("esperando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, str_proceso2, str_proceso3, "procesando",str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
//                  Constantes.ENVIAR_A="Preparación: procesando";
//                  RCB.PDF();
              }  if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("aprobado")&&str_proceso4.equals("procesando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, str_proceso2, str_proceso3, "aprobado",str_proceso5,str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
                  Constantes.ENVIAR_A="Preparacion: aprobado\nEnviar a: Empaque";
                  RCB.PDF();
              }
                //////////////////////////proceso5/////////////
               if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("aprobado")&&str_proceso4.equals("aprobado")&&str_proceso5.equals("esperando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, str_proceso2, str_proceso3, str_proceso4,"procesando",str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
//                  Constantes.ENVIAR_A="Empaque: procesando";
//                  RCB.PDF();
              }  if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("aprobado")&&str_proceso4.equals("aprobado")&&str_proceso5.equals("procesando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, str_proceso2, str_proceso3, str_proceso4,"aprobado",str_proceso6, CODIGO_DE_BARRAS);
                  actualizar_status();
                  Constantes.ENVIAR_A="Empaque: aprobado\n Enviar a: Esterilización";
                  RCB.PDF();
              }
               ///////////////////proceso6////////////////////
               if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("aprobado")&&str_proceso4.equals("aprobado")&&str_proceso5.equals("aprobado")&&str_proceso6.equals("esperando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                  UP.update_procesos(str_proceso1, str_proceso2, str_proceso3, str_proceso4,str_proceso5,"procesando", CODIGO_DE_BARRAS);
                  actualizar_status();
//                  Constantes.ENVIAR_A="Esterilizacion: procesando";
//                  RCB.PDF();
              }  if(str_proceso1.equals("aprobado")&&str_proceso2.equals("aprobado")&&str_proceso3.equals("aprobado")&&str_proceso4.equals("aprobado")&&str_proceso5.equals("aprobado")&&str_proceso6.equals("procesando")){
                  UPDATE_PROCESOS UP=new UPDATE_PROCESOS();
                 UP.update_procesos(str_proceso1, str_proceso2, str_proceso3, str_proceso4,str_proceso5,"aprobado", CODIGO_DE_BARRAS);
                  actualizar_status();
                  Constantes.ENVIAR_A="Esterilización: aprobada\nPROCESOS TERMINADOS";
                  RCB.PDF();
              }
            }
         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_USUARIO.class.getName()).log(Level.SEVERE, null, ex);
        }     
        }


   

    String dato1_usuario = "(5)";
String dato2_usuario_nombre = "";
    public void notificacion() {
        String sqll = "SELECT * FROM tbl_usuario where str_id_usuario='" + CODIGO_DE_BARRAS + "'";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                dato1_usuario = rss.getString("str_id_usuario");
                dato2_usuario_nombre=rss.getString("str_n_usuario");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_USUARIO.class.getName()).log(Level.SEVERE, null, ex);
        }
//        try {
//            cnu.close();
//        } catch (SQLException ex) {
//            Logger.getLogger(VENTANA_USUARIO.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        panel1 = new org.edisoncor.gui.panel.Panel();
        panelShadow1 = new org.edisoncor.gui.panel.PanelShadow();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        txt_codigo_de_barras = new javax.swing.JTextField();
        lbl_me = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        panelShadow3 = new org.edisoncor.gui.panel.PanelShadow();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_noti = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
        });

        panel1.setColorPrimario(new java.awt.Color(255, 255, 255));
        panel1.setColorSecundario(new java.awt.Color(255, 255, 255));

        jButton2.setBackground(new java.awt.Color(153, 255, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/check-list.png"))); // NOI18N
        jButton2.setText("Actualizar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        txt_codigo_de_barras.setFont(new java.awt.Font("Swis721 Blk BT", 1, 14)); // NOI18N
        txt_codigo_de_barras.setOpaque(false);
        txt_codigo_de_barras.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_codigo_de_barrasKeyPressed(evt);
            }
        });

        lbl_me.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        lbl_me.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_me.setText("jLabel1");

        jButton5.setBackground(new java.awt.Color(0, 204, 204));
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir ses.png"))); // NOI18N
        jButton5.setText("Cerrar Sesión");
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 102)));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_me, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(txt_codigo_de_barras, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lbl_me, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(txt_codigo_de_barras, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout panelShadow1Layout = new javax.swing.GroupLayout(panelShadow1);
        panelShadow1.setLayout(panelShadow1Layout);
        panelShadow1Layout.setHorizontalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelShadow1Layout.setVerticalGroup(
            panelShadow1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelShadow1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelShadow3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelShadow3MouseClicked(evt);
            }
        });

        jInternalFrame1.setTitle("ESTATUS DE LOS PROCESOS");
        jInternalFrame1.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_en_operacion.png"))); // NOI18N
        jInternalFrame1.setVisible(true);
        jInternalFrame1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jInternalFrame1MouseClicked(evt);
            }
        });

        jScrollPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane2MouseClicked(evt);
            }
        });

        tbl_noti.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_noti.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_notiMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_noti);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 497, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panelShadow3Layout = new javax.swing.GroupLayout(panelShadow3);
        panelShadow3.setLayout(panelShadow3Layout);
        panelShadow3Layout.setHorizontalGroup(
            panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jInternalFrame1)
                .addContainerGap())
        );
        panelShadow3Layout.setVerticalGroup(
            panelShadow3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelShadow3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jInternalFrame1)
                .addContainerGap())
        );

        try {
            jInternalFrame1.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelShadow1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelShadow3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addComponent(panelShadow1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelShadow3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        actualizar_status();
        txt_codigo_de_barras.requestFocus();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jScrollPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane2MouseClicked
        txt_codigo_de_barras.requestFocus();        // TODO add your handling code here:
    }//GEN-LAST:event_jScrollPane2MouseClicked
boolean hola=true;
    private void tbl_notiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_notiMouseClicked
        Reporte_code_barras RCB=new Reporte_code_barras();
        txt_codigo_de_barras.requestFocus();
        
        int contador = tbl_noti.getSelectedRow();//lee el N° de columna  que seleccionamos
        Constantes.CODIGO_DE_BARRAS = (String) tbl_noti.getValueAt(contador, 0);//obtiene el valor de una celda 
        Constantes.NOMBRE_PAQUETE = (String) tbl_noti.getValueAt(contador, 1);//obtiene el valor de una celda 
        Constantes.DEPARTAMENTO = (String) tbl_noti.getValueAt(contador, 4);//obtiene el valor de una celda
        String prelavado= (String) tbl_noti.getValueAt(contador, 5);//obtiene el valor de una celda
         String proceso_final= (String) tbl_noti.getValueAt(contador, 10);//obtiene el valor de una celda
       
           if(proceso_final.equals("procesando")&&hola==true){
          JOptionPane.showMessageDialog(tbl_noti, "Mostrando grafica");    
          hola=false;
//          grafica();
//         hilo1.resume();
          
         }
         
         if(proceso_final.equals("aprobado")){
          JOptionPane.showMessageDialog(tbl_noti, "Espera que el Administrador remueva esta columna");    
         }else{
         
        if(prelavado.equals("esperando")){
          Constantes.ENVIAR_A="Enviar a: Prelavado";
       RCB.PDF();  
        }else{
            JOptionPane.showMessageDialog(tbl_noti, "Este paquete esta siendo procesado en alguna etapa");
        }
        
         }
       
    }//GEN-LAST:event_tbl_notiMouseClicked

    private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
        txt_codigo_de_barras.requestFocus();        // TODO add your handling code here:
    }//GEN-LAST:event_formMouseEntered
    static String CODIGO_DE_BARRAS = "";
    private void txt_codigo_de_barrasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_codigo_de_barrasKeyPressed
        if (evt.getKeyCode() == Event.ENTER) {
            if(verdad==false){
    lbl_me.setText("Identificate con tu QR");
}
               // System.out.println("" + verdad);
//mensaje que muestra si el usuario esta registrado cada tiempo
                CODIGO_DE_BARRAS = txt_codigo_de_barras.getText();
                notificacion();
                if (CODIGO_DE_BARRAS.equals(dato1_usuario) && verdad == false) {
                    verdad = true;
                    dato1_usuario = "(5)";
                    txt_codigo_de_barras.setText("");
                }

                if (verdad == true) {
                     lbl_me.setText("Ingresa el codigo de barras del paquete"); 
                    if (CODIGO_DE_BARRAS.length() == 13) {

//                        int ult = CODIGO_DE_BARRAS.length();
//                        String ultimo = CODIGO_DE_BARRAS.substring(ult - 1);
//                        System.out.println("cero");
//                        if (CODIGO_DE_BARRAS.substring(ult - 1).equals("7")) {
                            System.out.println("resultado: " + CODIGO_DE_BARRAS + "    ultimo: " );
                          
                           LEER_CODIGO(CODIGO_DE_BARRAS);
                            txt_codigo_de_barras.setText("");
                            verdad = false;

                    }
                }
            
                    if(verdad==false){
    lbl_me.setText("Identificate con tu QR");
}
            
            
//            CODIGO_DE_BARRAS = txt_codigo_de_barras.getText();
//            int ult = CODIGO_DE_BARRAS.length();
//            String ultimo = CODIGO_DE_BARRAS.substring(ult - 1);
//            System.out.println("resultado: " + CODIGO_DE_BARRAS + "    ultimo: " + ultimo);
//
//            txt_codigo_de_barras.setText("");
  }
    }//GEN-LAST:event_txt_codigo_de_barrasKeyPressed

    private void panelShadow3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelShadow3MouseClicked
        txt_codigo_de_barras.requestFocus();
    }//GEN-LAST:event_panelShadow3MouseClicked

    private void jInternalFrame1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jInternalFrame1MouseClicked
        txt_codigo_de_barras.requestFocus();
    }//GEN-LAST:event_jInternalFrame1MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if(Constantes.VENTANAS==true){
            JOptionPane.showMessageDialog(null, "ESTAS COMO ADMINISTRADOR VISOR ESTA INTERFAZ SERA CERRADA","INFORMACION",JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
        }else{
            Constantes.ID="";
            Constantes.CANTIDAD="";
            Constantes.NOMBRE_PAQUETE="";
            Constantes.ID_USUARIO="";
            Constantes.ID_TIPO_USUARIO="";
            Constantes.ID_NOMBRE_USUARIO="";
            Constantes.CODIGO_DE_BARRAS="";
            Constantes.INCLUYE="";
            Constantes.DEPARTAMENTO="";
            Constantes.ENVIAR_A="";
            Constantes.ULTIMO_DIGITO="";
            Constantes.ID_INSTRUMENTOS="";
            Constantes.ID_CIRUGIAS="";
            Constantes.DIRECCION_PDF="";
            Constantes.ID_INSTRUMENTO_IMAGEN="";
            this.dispose();
            LOGUEO LO=new LOGUEO();
            LO.setVisible(true);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbl_me;
    private org.edisoncor.gui.panel.Panel panel1;
    private org.edisoncor.gui.panel.PanelShadow panelShadow1;
    private org.edisoncor.gui.panel.PanelShadow panelShadow3;
    private javax.swing.JTable tbl_noti;
    private javax.swing.JTextField txt_codigo_de_barras;
    // End of variables declaration//GEN-END:variables

    private void actualizar_status() {
        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_noti.getModel();
        for (int i = 0; i < tbl_noti.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_proceso ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_cantidad");
                String dato4 = rss.getString("str_incluye");
                String dato5 = rss.getString("str_departamento");
                String dato6 = rss.getString("str_proceso1");
                String dato7 = rss.getString("str_proceso2");
                String dato8 = rss.getString("str_proceso3");
                String dato9 = rss.getString("str_proceso4");
                String dato10 = rss.getString("str_proceso5");
                String dato11 = rss.getString("str_proceso6");

                String instrumentos[] = {dato1, dato2, dato3, dato4, dato5, dato6, dato7, dato8, dato9,dato10,dato11};
                md_noti.addRow(instrumentos);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_USUARIO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    ///////////////////////////grafica con su respectivo hilo////////////////////////////////////
   
//    
//    
//    Thread hilo1 = new Thread() {
//        @Override
//        public void run() {
//            try {
//                
//
//                while (true) {
//                  
//                    if (h1 == tiempo_espera) {
//                      
//                        grafica();
//                        ChartUtilities.saveChartAsJPEG(new File("grafica.png"), chart, 1500, 550);
//                        hola=true;
//                        hilo1.suspend();
//                        h1 = 0;
//
//                    }
//
//                  temperatura++;
//                  TEMP.add(temperatura);
//                  
//                  pascal++;
//                  pascal=pascal+4;
//                  PASC.add(pascal);
//                  tiempo=""+h1;
//                    System.out.println("Thread= " + h1);
//grafica();
//                    h1++;
//                    
//                    hilo1.sleep(1000);
//                }
//            } catch (java.lang.InterruptedException ie) {
//                System.out.println(ie.getMessage());
//            } catch (IOException ex) {
//                Logger.getLogger(GRAFICA_ESTERILIZADOR.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//    };
//    
  
    
//     private void grafica() {
//
//        for (int i = 0; i <= TEMP.size() - 1; i++) {
//      line_chart_dataset.addValue(TEMP.get(i), "TEMPERATURA", tiempo);
//       }
//            for (int i = 0; i <= PASC.size() - 1; i++) {
//      line_chart_dataset.addValue(PASC.get(i), "PRESIÓN", tiempo);
//       }
//        
//        
//         
//
//        chart = ChartFactory.createLineChart("TEMPERATURAS y PRESIONES", "Minutos", "Temperaturas en °C y presión en PA",
//                line_chart_dataset, PlotOrientation.VERTICAL, true, true, false);
//
//        final CategoryPlot plot = (CategoryPlot) chart.getPlot();
//        final LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
////Puntos en las líneas o no
//        renderer.setSeriesShapesVisible(0, true);
//        renderer.setSeriesShapesVisible(1, true);
//        renderer.setSeriesShapesVisible(2, true);
////líneas visibles o no
//        renderer.setSeriesLinesVisible(0, true);
//        renderer.setSeriesLinesVisible(1, true);
//        renderer.setSeriesLinesVisible(2, true);
//////etiquetas con los valores visibles o no
////renderer.setItemLabelGenerator(new StandardCategoryItemLabelGenerator());
////renderer.setItemLabelsVisible(false);
//
//        // Mostrar Grafico
//        ChartPanel chartPanel = new ChartPanel(chart);
//        chartPanel.setSize(1500, 550);
//        chartPanel.setLocation(10, 20);
////       panel_grafica2.add(chartPanel);
////      panel_grafica2.show();
//
//    }
    
    
    
}
