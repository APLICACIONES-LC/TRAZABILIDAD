
package CLASE_CODIGO_FINAL;
import Constantes.Constantes;
/**
 *
 * @author ERICK IVAN
 */
public class ULTIMO_DIGITO {
     public int controlCodeCalculator(String firstTwelveDigits)
{
     char[] charDigits = firstTwelveDigits.toCharArray();
     int[] ean13 ={1, 3};
     int sum = 0;
     for(int i = 0; i < charDigits.length; i++)
     {
         sum += Character.getNumericValue(charDigits[i]) * ean13[i % 2];
     }
     int checksum = 10 - sum % 10;

     if(checksum == 10){
         checksum = 0;
     }
   Constantes.ULTIMO_DIGITO=""+checksum;
     System.out.println("--------------------------"+checksum);
     return checksum;
}
}
