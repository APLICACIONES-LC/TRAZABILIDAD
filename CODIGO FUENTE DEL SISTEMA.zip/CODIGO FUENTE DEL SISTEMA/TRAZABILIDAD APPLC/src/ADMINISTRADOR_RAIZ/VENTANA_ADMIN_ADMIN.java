/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ADMINISTRADOR_RAIZ;

import ADMINISTRADOR_MONITORISTA.DEVOLUCION;
import ADMINISTRADOR_MONITORISTA.VENTANA_ADMINISTRADOR_MONITORISTA;
import CLASES_DELETE.DELETE_CIRUGIA;
import CLASES_DELETE.DELETE_INSTRUMENTAL;
import CLASES_DELETE.DELETE_OPERACION;
import CLASES_DELETE.DELETE_USUARIO;
import CLASES_INSERT.INSERT_NUEVA_OPERACION_QUI;
import CLASES_INSERT.INSERT_NUEVO_INST_QUIRURGICO;
import CLASES_INSERT.INSERT_NUEVO_USUARIO;
import CLASES_SELECT.SELECT_BUSCAR_INSTRUMENTOS_QUIR;
import CLASES_SELECT.SELECT_BUSCAR_OPERACIONES;
import CLASES_SELECT.SELECT_INSERT_OPERACION_VALIDE;
import CLASES_SELECT.SELECT_INSERT_QUIRURGICO;
import CLASES_SELECT.SELECT_NOTIFICACION;
import CLASES_UPDATE.UPDATE_CIRUGIAS;
import CLASES_UPDATE.UPDATE_INSTRUMENTOS;
import CLASES_UPDATE.UPDATE_INSTRUMENTOS_IMAGEN;
import CLASES_UPDATE.UPDATE_USUARIOS;
import CONEXION.Conectar;
import Constantes.Constantes;
import LOGIN.LOGUEO;
import USUARIO.VENTANA_USUARIO;
import com.mxrck.autocompleter.TextAutoCompleter;
import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ERICK IVAN
 */
public class VENTANA_ADMIN_ADMIN extends javax.swing.JFrame {
    private static final long serialVersionUID = 1L;

    /////////////////////////////////////////////conexión//////////

    Conectar cu = new Conectar();
    Connection cnu = cu.conexion();
    ///////////////////////////////////////////////////////////
    public DefaultTableModel md_inicial;
    String[][] data2 = {};
    String[] columnas2 = {"ID", "NOMBRE", "STOCK", "EN OPERACIÓN", "TIPO"};

     public DefaultTableModel md_paquete_operando;
    String[][] data5 = {};
    String[] columnas5 = {"ID", "NOMBRE", "INCLUYE", "CANTIDAD", "DEPARTAMENTO", "STATUS"};
    
    
    ///////////////////////////////////////
    File archivo=null;
    ////////////////
    
    
    public VENTANA_ADMIN_ADMIN() {
        initComponents();
          Image icon = new ImageIcon(getClass().getResource("/IMG/iconfel100.png")).getImage();
        setIconImage(icon);
         int ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
       int alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;

        this.setLocation((ancho / 2) - (this.getWidth() / 2), (alto / 2) - (this.getHeight() / 2));
          this.setExtendedState(MAXIMIZED_BOTH);
         md_paquete_operando = new DefaultTableModel(data5, columnas5);
         tbl_en_operacion.setModel(md_paquete_operando);
         tbl_en_operacion.setRowHeight(45);
       tbl_en_operacion.getTableHeader().setReorderingAllowed(false) ;
        md_inicial = new DefaultTableModel(data2, columnas2);
        tbl_inicial.setModel(md_inicial);
        tbl_inicial.getTableHeader().setReorderingAllowed(false) ;
        tbl_inicial.getColumnModel().getColumn(0).setMaxWidth(50);
        tbl_inicial.getColumnModel().getColumn(0).setMinWidth(50);
        tbl_inicial.getColumnModel().getColumn(0).setPreferredWidth(50);
        tbl_inicial.getColumnModel().getColumn(4).setMaxWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setMinWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setPreferredWidth(0);
        tbl_inicial.setRowHeight(45);
           
        autocompletar();
auto_cirugias();
    }

    
    private void autocompletar() {
        TextAutoCompleter textAutoCompleter = new TextAutoCompleter(txt_filtro);
        String msql = "SELECT * FROM tbl_instrumentos ";
        Statement st;
        try {      
            st = cnu.createStatement();
            ResultSet rs = st.executeQuery(msql);
            while (rs.next()) {
                textAutoCompleter.addItem(rs.getString("str_id"));
                textAutoCompleter.addItem(rs.getString("str_nombre"));

            }

        } catch (SQLException ex) {
            Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
        }
      
      
    }
  
  private void auto_cirugias(){
       TextAutoCompleter textAutoCompleter = new TextAutoCompleter(txt_filtro);
      String msql2 = "SELECT * FROM tbl_n_operacion ";
        Statement st2;
        try {      
            st2 = cnu.createStatement();
            ResultSet rs2 = st2.executeQuery(msql2);
            while (rs2.next()) {
                textAutoCompleter.addItem(rs2.getString("str_nombre_operacion"));
              

            }

        } catch (SQLException ex) {
            Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
        }
  }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        panel1 = new org.edisoncor.gui.panel.Panel();
        FI_insert_instrumental = new javax.swing.JInternalFrame();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txt_insert_id_quirurgico = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        lbl_noti_insert = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_insert_nombre_quirurgico = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_insert_stock_quirur = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txt_insert_operacion = new javax.swing.JTextField();
        cmb_insert_operacion = new javax.swing.JComboBox();
        jButton2 = new javax.swing.JButton();
        lbl_imagen_nuevo = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        FI_insert_operaciones = new javax.swing.JInternalFrame();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txt_nombre_operacion_insert = new javax.swing.JTextField();
        btn_verificar_operacion = new javax.swing.JButton();
        lbl_valido_operaciones = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btn_insertar_operacion = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_descripcion_operacion_insert = new javax.swing.JTextArea();
        FI_editar_instrumental1 = new javax.swing.JInternalFrame();
        jPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txt_id_update = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        txt_n_i_q_update = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txt_s_i_q_update = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txt_instrumentacion_update = new javax.swing.JTextField();
        cmb_operacion_ins_update = new javax.swing.JComboBox();
        jButton6 = new javax.swing.JButton();
        cmb_id_instrumento_update = new javax.swing.JComboBox();
        jButton18 = new javax.swing.JButton();
        jLabel46 = new javax.swing.JLabel();
        lbl_imagen_editar = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        FI_editar_operaciones = new javax.swing.JInternalFrame();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txt_nombre_p_la_operacion_update = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txt_descripcion_para_operacion_update = new javax.swing.JTextArea();
        jLabel16 = new javax.swing.JLabel();
        txt_id_operacion_update = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        cmb_operacion_ins_update1 = new javax.swing.JComboBox();
        FI_eliminar_operaciones = new javax.swing.JInternalFrame();
        jPanel5 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        txt_nombre_operacion_delete = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        txt_descripcion_operacion_delete = new javax.swing.JTextArea();
        jLabel20 = new javax.swing.JLabel();
        txt_id_operacion_delete = new javax.swing.JTextField();
        jButton12 = new javax.swing.JButton();
        cmb_operacion_delete = new javax.swing.JComboBox();
        FI_eliminar_instrumental = new javax.swing.JInternalFrame();
        jPanel8 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        txt_id_instrumental_delete = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        txt_n_i_q_delete = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        txt_s_i_q_delete = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txt_instrumental_delete = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        cmb_id_instrumento_update1 = new javax.swing.JComboBox();
        lbl_imagen_eliminar = new javax.swing.JLabel();
        JI_FRAME_ESTERILIZACION = new javax.swing.JInternalFrame();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbl_inicial = new javax.swing.JTable();
        panel2 = new org.edisoncor.gui.panel.Panel();
        txt_filtro = new javax.swing.JTextField();
        jButton16 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        FI_eliminar_paquete_en_operacion = new javax.swing.JInternalFrame();
        jPanel9 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        txt_buscar_paquete_en_operacion = new javax.swing.JTextField();
        jButton13 = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        tbl_en_operacion = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        FI_NUEVO_USUARIO = new javax.swing.JInternalFrame();
        jPanel6 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_insert_id_usuario = new javax.swing.JTextField();
        btn_generar_id = new javax.swing.JButton();
        lbl_noti_insert1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_insert_nombre_usuario = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        txt_insert_contraseña = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        txt_insert_apellidos = new javax.swing.JTextField();
        cmb_insert_tipo_usuario = new javax.swing.JComboBox();
        jButton14 = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        txt_insert_nombre_persona = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        txt_insert_tipo_usuario = new javax.swing.JTextField();
        FI_EDITAR_USUARIO = new javax.swing.JInternalFrame();
        jPanel10 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        txt_insert_id_usuario1 = new javax.swing.JTextField();
        btn_generar_id1 = new javax.swing.JButton();
        lbl_noti_insert2 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        txt_insert_nombre_usuario1 = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        txt_insert_contraseña1 = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        txt_insert_apellidos1 = new javax.swing.JTextField();
        cmb_tipo_usuario1 = new javax.swing.JComboBox();
        jButton15 = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        txt_insert_nombre_persona1 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        txt_insert_tipo_usuario1 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        txt_buscar_usuario = new javax.swing.JTextField();
        cmb_id_usuario = new javax.swing.JComboBox();
        FI_ELIMINAR_USUARIO = new javax.swing.JInternalFrame();
        jPanel11 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        txt_insert_id_usuario2 = new javax.swing.JTextField();
        btn_generar_id2 = new javax.swing.JButton();
        lbl_noti_insert3 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        txt_insert_nombre_usuario2 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        txt_insert_contraseña2 = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        txt_insert_apellidos2 = new javax.swing.JTextField();
        cmb_tipo_usuario2 = new javax.swing.JComboBox();
        jButton17 = new javax.swing.JButton();
        jLabel41 = new javax.swing.JLabel();
        txt_insert_nombre_persona2 = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        txt_insert_tipo_usuario2 = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        txt_buscar_usuario1 = new javax.swing.JTextField();
        cmb_id_usuario1 = new javax.swing.JComboBox();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenuItem14 = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenu4.setText("jMenu4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("VENTANA DE ADMINISTRACIÓN");

        panel1.setColorPrimario(new java.awt.Color(255, 255, 255));
        panel1.setColorSecundario(new java.awt.Color(255, 255, 255));

        FI_insert_instrumental.setTitle("INSERTAR NUEVO INSTRUMENTAL QUIRURGICO");
        FI_insert_instrumental.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_instrumentacion.png"))); // NOI18N
        FI_insert_instrumental.setVisible(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel1.setText("ID del instrumento quirurgico:");

        txt_insert_id_quirurgico.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/portapapeles.png"))); // NOI18N
        jButton1.setText("Verificar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        lbl_noti_insert.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        lbl_noti_insert.setForeground(new java.awt.Color(0, 153, 0));

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setText("Nombre del instrumento quirurgico:");

        txt_insert_nombre_quirurgico.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel4.setText("Stock del instrumento quirurgico:");

        txt_insert_stock_quirur.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_insert_stock_quirur.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_insert_stock_quirurKeyTyped(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel5.setText("Operación.");

        txt_insert_operacion.setEditable(false);
        txt_insert_operacion.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        cmb_insert_operacion.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-" }));
        cmb_insert_operacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_insert_operacionActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/aceptar.png"))); // NOI18N
        jButton2.setText("Aceptar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        lbl_imagen_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/vacio.png"))); // NOI18N
        lbl_imagen_nuevo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/buscar_imagen.png"))); // NOI18N
        jButton4.setText("Buscar imagen");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel44.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel44.setText("<html> la imagen debe tener una medida de<br/><br/><br/> 512 x 512px<br/><br/><br/>\npara que puedas tener una buena experiencia visual.<html>");

        jLabel45.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel45.setText("Formato de imagen .PNG menor a 2MB");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_insert_operacion)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_stock_quirur, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_nombre_quirurgico, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_id_quirurgico, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cmb_insert_operacion, 0, 122, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(lbl_noti_insert, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(lbl_imagen_nuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 51, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_insert_id_quirurgico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_noti_insert, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_nombre_quirurgico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_stock_quirur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_insert_operacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_insert_operacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(lbl_imagen_nuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jLabel45))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
        );

        javax.swing.GroupLayout FI_insert_instrumentalLayout = new javax.swing.GroupLayout(FI_insert_instrumental.getContentPane());
        FI_insert_instrumental.getContentPane().setLayout(FI_insert_instrumentalLayout);
        FI_insert_instrumentalLayout.setHorizontalGroup(
            FI_insert_instrumentalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_insert_instrumentalLayout.setVerticalGroup(
            FI_insert_instrumentalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_insert_operaciones.setTitle("INSERTAR NUEVA OPERACION");
        FI_insert_operaciones.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_cirugia.png"))); // NOI18N
        FI_insert_operaciones.setVisible(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel6.setText("Nombre para la operacion:");

        txt_nombre_operacion_insert.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_nombre_operacion_insert.setToolTipText("ejemplo: cirugia de cabeza, cirugia apendice.");

        btn_verificar_operacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/portapapeles.png"))); // NOI18N
        btn_verificar_operacion.setText("Verificar");
        btn_verificar_operacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_verificar_operacionActionPerformed(evt);
            }
        });

        lbl_valido_operaciones.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        lbl_valido_operaciones.setForeground(new java.awt.Color(0, 153, 0));

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel8.setText("Descripción:");

        btn_insertar_operacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/aceptar.png"))); // NOI18N
        btn_insertar_operacion.setText("Aceptar");
        btn_insertar_operacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_insertar_operacionActionPerformed(evt);
            }
        });

        txt_descripcion_operacion_insert.setColumns(20);
        txt_descripcion_operacion_insert.setRows(5);
        jScrollPane1.setViewportView(txt_descripcion_operacion_insert);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_insertar_operacion)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                            .addComponent(txt_nombre_operacion_insert, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_verificar_operacion, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_valido_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(70, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_nombre_operacion_insert, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_verificar_operacion)
                    .addComponent(lbl_valido_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_insertar_operacion)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout FI_insert_operacionesLayout = new javax.swing.GroupLayout(FI_insert_operaciones.getContentPane());
        FI_insert_operaciones.getContentPane().setLayout(FI_insert_operacionesLayout);
        FI_insert_operacionesLayout.setHorizontalGroup(
            FI_insert_operacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_insert_operacionesLayout.setVerticalGroup(
            FI_insert_operacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_editar_instrumental1.setTitle("EDITAR INSTRUMENTAL QUIRURGICO");
        FI_editar_instrumental1.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_instrumentacion.png"))); // NOI18N
        FI_editar_instrumental1.setVisible(false);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel11.setText("Buscar por ID:");

        txt_id_update.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/buscando.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel13.setText("Nombre del instrumento quirurgico:");

        txt_n_i_q_update.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel14.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel14.setText("Stock del instrumento quirurgico:");

        txt_s_i_q_update.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_s_i_q_update.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_s_i_q_updateKeyTyped(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel15.setText("Operación.");

        txt_instrumentacion_update.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        cmb_operacion_ins_update.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "selecciona" }));
        cmb_operacion_ins_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_operacion_ins_updateActionPerformed(evt);
            }
        });

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/misma_imagen.png"))); // NOI18N
        jButton6.setText("Actualizar con la misma imagen");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        cmb_id_instrumento_update.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-" }));
        cmb_id_instrumento_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_id_instrumento_updateActionPerformed(evt);
            }
        });

        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/buscar_imagen.png"))); // NOI18N
        jButton18.setText("Buscar imagen");
        jButton18.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton18.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(51, 204, 0));
        jLabel46.setText("Formato de imagen .PNG menor a 2MB");

        lbl_imagen_editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/vacio.png"))); // NOI18N
        lbl_imagen_editar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lbl_imagen_editar.setPreferredSize(new java.awt.Dimension(512, 512));

        jLabel47.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel47.setText("<html> la imagen debe tener una medida de<br/><br/><br/> 512 x 512px<br/><br/><br/>\npara que puedas tener una buena experiencia visual.<html>");

        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/actualizar_imagen.png"))); // NOI18N
        jButton19.setText("Actualizar con nueva imagen");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_instrumentacion_update)
                            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_s_i_q_update, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_n_i_q_update, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_id_update, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cmb_id_instrumento_update, 0, 127, Short.MAX_VALUE)
                            .addComponent(cmb_operacion_ins_update, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton5))
                    .addComponent(jButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbl_imagen_editar, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton19)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel47, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_imagen_editar, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton18)
                            .addComponent(jButton19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel46)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_id_update, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton5)
                                .addComponent(cmb_id_instrumento_update, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_n_i_q_update, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_s_i_q_update, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_instrumentacion_update, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_operacion_ins_update, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39)
                        .addComponent(jButton6))))
        );

        javax.swing.GroupLayout FI_editar_instrumental1Layout = new javax.swing.GroupLayout(FI_editar_instrumental1.getContentPane());
        FI_editar_instrumental1.getContentPane().setLayout(FI_editar_instrumental1Layout);
        FI_editar_instrumental1Layout.setHorizontalGroup(
            FI_editar_instrumental1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_editar_instrumental1Layout.setVerticalGroup(
            FI_editar_instrumental1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_editar_operaciones.setTitle("EDITAR LA OPERACION");
        FI_editar_operaciones.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_cirugia.png"))); // NOI18N
        FI_editar_operaciones.setVisible(false);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel9.setText("Nombre para la operacion:");

        txt_nombre_p_la_operacion_update.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_nombre_p_la_operacion_update.setToolTipText("ejemplo: cirugia de cabeza, cirugia apendice.");

        jLabel10.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 153, 0));

        jLabel12.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel12.setText("Descripción:");

        jButton8.setText("Aceptar");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        txt_descripcion_para_operacion_update.setColumns(20);
        txt_descripcion_para_operacion_update.setRows(5);
        jScrollPane3.setViewportView(txt_descripcion_para_operacion_update);

        jLabel16.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel16.setText("ID operacion:");

        txt_id_operacion_update.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_id_operacion_update.setToolTipText("ejemplo: cirugia de cabeza, cirugia apendice.");

        jButton9.setText("Buscar");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        cmb_operacion_ins_update1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-" }));
        cmb_operacion_ins_update1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_operacion_ins_update1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton8)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_id_operacion_update))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                            .addComponent(txt_nombre_p_la_operacion_update, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(cmb_operacion_ins_update1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(421, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_id_operacion_update, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9)
                    .addComponent(cmb_operacion_ins_update1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_nombre_p_la_operacion_update, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8)
                .addContainerGap(198, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout FI_editar_operacionesLayout = new javax.swing.GroupLayout(FI_editar_operaciones.getContentPane());
        FI_editar_operaciones.getContentPane().setLayout(FI_editar_operacionesLayout);
        FI_editar_operacionesLayout.setHorizontalGroup(
            FI_editar_operacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_editar_operacionesLayout.setVerticalGroup(
            FI_editar_operacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_eliminar_operaciones.setTitle("ELIMINAR LA OPERACION");
        FI_eliminar_operaciones.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_cirugia.png"))); // NOI18N
        FI_eliminar_operaciones.setVisible(false);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel17.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel17.setText("Nombre para la operacion:");

        txt_nombre_operacion_delete.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_nombre_operacion_delete.setToolTipText("ejemplo: cirugia de cabeza, cirugia apendice.");

        jLabel19.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel19.setText("Descripción:");

        jButton11.setText("Aceptar");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        txt_descripcion_operacion_delete.setColumns(20);
        txt_descripcion_operacion_delete.setRows(5);
        jScrollPane4.setViewportView(txt_descripcion_operacion_delete);

        jLabel20.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel20.setText("ID operacion:");

        txt_id_operacion_delete.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_id_operacion_delete.setToolTipText("ejemplo: cirugia de cabeza, cirugia apendice.");

        jButton12.setText("Buscar");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        cmb_operacion_delete.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-" }));
        cmb_operacion_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_operacion_deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton11)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel20)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txt_id_operacion_delete))
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                            .addComponent(txt_nombre_operacion_delete, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmb_operacion_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton12)))
                .addContainerGap(83, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_id_operacion_delete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12)
                    .addComponent(cmb_operacion_delete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_nombre_operacion_delete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton11)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout FI_eliminar_operacionesLayout = new javax.swing.GroupLayout(FI_eliminar_operaciones.getContentPane());
        FI_eliminar_operaciones.getContentPane().setLayout(FI_eliminar_operacionesLayout);
        FI_eliminar_operacionesLayout.setHorizontalGroup(
            FI_eliminar_operacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_eliminar_operacionesLayout.setVerticalGroup(
            FI_eliminar_operacionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_eliminar_instrumental.setTitle("ELIMINAR INSTRUMENTAL QUIRURGICO");
        FI_eliminar_instrumental.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_instrumentacion.png"))); // NOI18N
        FI_eliminar_instrumental.setVisible(false);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel18.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel18.setText("Buscar por ID:");

        txt_id_instrumental_delete.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jButton7.setText("Buscar");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel26.setText("Nombre del instrumento quirurgico:");

        txt_n_i_q_delete.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel27.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel27.setText("Stock del instrumento quirurgico:");

        txt_s_i_q_delete.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel28.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel28.setText("Operación.");

        txt_instrumental_delete.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jButton10.setText("Eliminar");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        cmb_id_instrumento_update1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-" }));
        cmb_id_instrumento_update1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_id_instrumento_update1ActionPerformed(evt);
            }
        });

        lbl_imagen_eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/vacio.png"))); // NOI18N
        lbl_imagen_eliminar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton10)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_instrumental_delete)
                            .addComponent(jLabel28, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_s_i_q_delete, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_n_i_q_delete, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_id_instrumental_delete, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmb_id_instrumento_update1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_imagen_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_imagen_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_id_instrumental_delete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7)
                            .addComponent(cmb_id_instrumento_update1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_n_i_q_delete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_s_i_q_delete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_instrumental_delete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(jButton10)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout FI_eliminar_instrumentalLayout = new javax.swing.GroupLayout(FI_eliminar_instrumental.getContentPane());
        FI_eliminar_instrumental.getContentPane().setLayout(FI_eliminar_instrumentalLayout);
        FI_eliminar_instrumentalLayout.setHorizontalGroup(
            FI_eliminar_instrumentalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_eliminar_instrumentalLayout.setVerticalGroup(
            FI_eliminar_instrumentalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        JI_FRAME_ESTERILIZACION.setTitle("Tabla");
        JI_FRAME_ESTERILIZACION.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_instrumentacion.png"))); // NOI18N
        JI_FRAME_ESTERILIZACION.setVisible(true);

        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jPanel7.setLayout(new javax.swing.BoxLayout(jPanel7, javax.swing.BoxLayout.LINE_AXIS));

        tbl_inicial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"<HTML> HOLA<br/>si tu<html>", null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_inicial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_inicialMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tbl_inicial);

        jPanel7.add(jScrollPane5);

        jScrollPane2.setViewportView(jPanel7);

        panel2.setColorPrimario(new java.awt.Color(255, 255, 255));
        panel2.setColorSecundario(new java.awt.Color(255, 255, 255));

        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/buscando.png"))); // NOI18N
        jButton16.setText("Buscar");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel25.setText("Buscar por filtro");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                    .addComponent(txt_filtro))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton16)
                .addContainerGap(581, Short.MAX_VALUE))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_filtro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton16))
                .addContainerGap())
        );

        javax.swing.GroupLayout JI_FRAME_ESTERILIZACIONLayout = new javax.swing.GroupLayout(JI_FRAME_ESTERILIZACION.getContentPane());
        JI_FRAME_ESTERILIZACION.getContentPane().setLayout(JI_FRAME_ESTERILIZACIONLayout);
        JI_FRAME_ESTERILIZACIONLayout.setHorizontalGroup(
            JI_FRAME_ESTERILIZACIONLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 934, Short.MAX_VALUE)
        );
        JI_FRAME_ESTERILIZACIONLayout.setVerticalGroup(
            JI_FRAME_ESTERILIZACIONLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JI_FRAME_ESTERILIZACIONLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 453, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        FI_eliminar_paquete_en_operacion.setTitle("ELIMINAR PAQUETE  DE INSTRUMENTAL QUIRURGICO");
        FI_eliminar_paquete_en_operacion.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_frame_paquete.png"))); // NOI18N
        FI_eliminar_paquete_en_operacion.setVisible(false);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jLabel21.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel21.setText("Buscar por CODIGO:");

        txt_buscar_paquete_en_operacion.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jButton13.setText("Buscar");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        tbl_en_operacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane6.setViewportView(tbl_en_operacion);

        jButton3.setText("Eliminar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 391, Short.MAX_VALUE)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, 157, Short.MAX_VALUE)
                                    .addComponent(txt_buscar_paquete_en_operacion, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_buscar_paquete_en_operacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addContainerGap())
        );

        javax.swing.GroupLayout FI_eliminar_paquete_en_operacionLayout = new javax.swing.GroupLayout(FI_eliminar_paquete_en_operacion.getContentPane());
        FI_eliminar_paquete_en_operacion.getContentPane().setLayout(FI_eliminar_paquete_en_operacionLayout);
        FI_eliminar_paquete_en_operacionLayout.setHorizontalGroup(
            FI_eliminar_paquete_en_operacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_eliminar_paquete_en_operacionLayout.setVerticalGroup(
            FI_eliminar_paquete_en_operacionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_NUEVO_USUARIO.setTitle("INSERTAR NUEVO USUARIO");
        FI_NUEVO_USUARIO.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_usuario_añadir.png"))); // NOI18N
        FI_NUEVO_USUARIO.setVisible(false);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel2.setText("ID del usuario:");

        txt_insert_id_usuario.setEditable(false);
        txt_insert_id_usuario.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        btn_generar_id.setText("Generar");
        btn_generar_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_generar_idActionPerformed(evt);
            }
        });

        lbl_noti_insert1.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        lbl_noti_insert1.setForeground(new java.awt.Color(0, 153, 0));

        jLabel7.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel7.setText("Nombre para el usuario:");

        txt_insert_nombre_usuario.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel22.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel22.setText("Contraseña para el usuario");

        txt_insert_contraseña.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel23.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel23.setText("Apellidos:");

        txt_insert_apellidos.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_insert_apellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_insert_apellidosActionPerformed(evt);
            }
        });

        cmb_insert_tipo_usuario.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-", "principiante", "moderador", "administrador_raiz" }));
        cmb_insert_tipo_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_insert_tipo_usuarioActionPerformed(evt);
            }
        });

        jButton14.setText("Añadir");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel24.setText("Nombre de la persona:");

        txt_insert_nombre_persona.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel29.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel29.setText("Tipo de usuario:");

        txt_insert_tipo_usuario.setEditable(false);
        txt_insert_tipo_usuario.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_insert_tipo_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_insert_tipo_usuarioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_contraseña, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_nombre_usuario, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_id_usuario, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(18, 18, 18)
                        .addComponent(btn_generar_id, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl_noti_insert1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_insert_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_insert_nombre_persona, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(txt_insert_tipo_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmb_insert_tipo_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton14))
                .addGap(0, 94, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_insert_id_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_generar_id)
                    .addComponent(lbl_noti_insert1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_insert_nombre_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_insert_contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_insert_nombre_persona, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_insert_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_insert_tipo_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmb_insert_tipo_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout FI_NUEVO_USUARIOLayout = new javax.swing.GroupLayout(FI_NUEVO_USUARIO.getContentPane());
        FI_NUEVO_USUARIO.getContentPane().setLayout(FI_NUEVO_USUARIOLayout);
        FI_NUEVO_USUARIOLayout.setHorizontalGroup(
            FI_NUEVO_USUARIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_NUEVO_USUARIOLayout.setVerticalGroup(
            FI_NUEVO_USUARIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_EDITAR_USUARIO.setTitle("EDITAR USUARIO");
        FI_EDITAR_USUARIO.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_usuario_añadir.png"))); // NOI18N
        FI_EDITAR_USUARIO.setVisible(false);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        jLabel30.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel30.setText("Buscar por ID del usuario:");

        txt_insert_id_usuario1.setEditable(false);
        txt_insert_id_usuario1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        btn_generar_id1.setText("Generar");
        btn_generar_id1.setEnabled(false);
        btn_generar_id1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_generar_id1ActionPerformed(evt);
            }
        });

        lbl_noti_insert2.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        lbl_noti_insert2.setForeground(new java.awt.Color(0, 153, 0));

        jLabel31.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel31.setText("Nombre para el usuario:");

        txt_insert_nombre_usuario1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel32.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel32.setText("Contraseña para el usuario");

        txt_insert_contraseña1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel33.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel33.setText("Apellidos:");

        txt_insert_apellidos1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_insert_apellidos1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_insert_apellidos1ActionPerformed(evt);
            }
        });

        cmb_tipo_usuario1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-", "principiante", "moderador", "administrador_raiz" }));
        cmb_tipo_usuario1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_tipo_usuario1ActionPerformed(evt);
            }
        });

        jButton15.setText("Actualizar");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jLabel34.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel34.setText("Nombre de la persona:");

        txt_insert_nombre_persona1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel35.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel35.setText("Tipo de usuario:");

        txt_insert_tipo_usuario1.setEditable(false);
        txt_insert_tipo_usuario1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_insert_tipo_usuario1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_insert_tipo_usuario1ActionPerformed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel36.setText("ID del usuario:");

        txt_buscar_usuario.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        cmb_id_usuario.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-", "USU-ES-1000000" }));
        cmb_id_usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_id_usuarioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_insert_apellidos1, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_insert_nombre_persona1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addComponent(txt_insert_tipo_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cmb_tipo_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton15))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 383, Short.MAX_VALUE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(561, 561, 561)))
                        .addComponent(lbl_noti_insert2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_contraseña1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel32, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_nombre_usuario1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_id_usuario1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_generar_id1, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                            .addComponent(txt_buscar_usuario))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmb_id_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(lbl_noti_insert2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_buscar_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_id_usuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_insert_id_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_generar_id1))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_nombre_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_contraseña1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_nombre_persona1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_insert_apellidos1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_insert_tipo_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_tipo_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton15)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout FI_EDITAR_USUARIOLayout = new javax.swing.GroupLayout(FI_EDITAR_USUARIO.getContentPane());
        FI_EDITAR_USUARIO.getContentPane().setLayout(FI_EDITAR_USUARIOLayout);
        FI_EDITAR_USUARIOLayout.setHorizontalGroup(
            FI_EDITAR_USUARIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_EDITAR_USUARIOLayout.setVerticalGroup(
            FI_EDITAR_USUARIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        FI_ELIMINAR_USUARIO.setTitle("ELIMINAR USUARIO");
        FI_ELIMINAR_USUARIO.setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icono_usuario_eliminar.png"))); // NOI18N
        FI_ELIMINAR_USUARIO.setVisible(false);

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));

        jLabel37.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel37.setText("Buscar por ID del usuario:");

        txt_insert_id_usuario2.setEditable(false);
        txt_insert_id_usuario2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        btn_generar_id2.setText("Generar");
        btn_generar_id2.setEnabled(false);
        btn_generar_id2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_generar_id2ActionPerformed(evt);
            }
        });

        lbl_noti_insert3.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        lbl_noti_insert3.setForeground(new java.awt.Color(0, 153, 0));

        jLabel38.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel38.setText("Nombre para el usuario:");

        txt_insert_nombre_usuario2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel39.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel39.setText("Contraseña para el usuario");

        txt_insert_contraseña2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel40.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel40.setText("Apellidos:");

        txt_insert_apellidos2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_insert_apellidos2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_insert_apellidos2ActionPerformed(evt);
            }
        });

        cmb_tipo_usuario2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-", "principiante", "moderador", "administrador_raiz" }));
        cmb_tipo_usuario2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_tipo_usuario2ActionPerformed(evt);
            }
        });

        jButton17.setText("Eliminar");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel41.setText("Nombre de la persona:");

        txt_insert_nombre_persona2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        jLabel42.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel42.setText("Tipo de usuario:");

        txt_insert_tipo_usuario2.setEditable(false);
        txt_insert_tipo_usuario2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txt_insert_tipo_usuario2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_insert_tipo_usuario2ActionPerformed(evt);
            }
        });

        jLabel43.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel43.setText("ID del usuario:");

        txt_buscar_usuario1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        cmb_id_usuario1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-selecciona-", "USU-ES-1000000" }));
        cmb_id_usuario1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmb_id_usuario1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_insert_apellidos2, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_insert_nombre_persona2, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel11Layout.createSequentialGroup()
                                        .addComponent(txt_insert_tipo_usuario2, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cmb_tipo_usuario2, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton17))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                                .addGap(561, 561, 561)))
                        .addComponent(lbl_noti_insert3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_contraseña2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel39, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_nombre_usuario2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_insert_id_usuario2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_generar_id2, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                            .addComponent(txt_buscar_usuario1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmb_id_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(lbl_noti_insert3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_buscar_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_id_usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_insert_id_usuario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_generar_id2))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_nombre_usuario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_contraseña2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_insert_nombre_persona2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_insert_apellidos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_insert_tipo_usuario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmb_tipo_usuario2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton17)))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout FI_ELIMINAR_USUARIOLayout = new javax.swing.GroupLayout(FI_ELIMINAR_USUARIO.getContentPane());
        FI_ELIMINAR_USUARIO.getContentPane().setLayout(FI_ELIMINAR_USUARIOLayout);
        FI_ELIMINAR_USUARIOLayout.setHorizontalGroup(
            FI_ELIMINAR_USUARIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        FI_ELIMINAR_USUARIOLayout.setVerticalGroup(
            FI_ELIMINAR_USUARIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FI_insert_instrumental, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_insert_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_editar_instrumental1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_editar_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_eliminar_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_eliminar_instrumental, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(JI_FRAME_ESTERILIZACION)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_eliminar_paquete_en_operacion, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_NUEVO_USUARIO, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_EDITAR_USUARIO, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_ELIMINAR_USUARIO, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FI_insert_instrumental, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(FI_insert_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(FI_editar_instrumental1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_editar_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(FI_eliminar_operaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_eliminar_instrumental, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(JI_FRAME_ESTERILIZACION)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(FI_eliminar_paquete_en_operacion, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(FI_NUEVO_USUARIO, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(FI_EDITAR_USUARIO, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(FI_ELIMINAR_USUARIO, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        try {
            FI_insert_instrumental.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_insert_operaciones.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_editar_instrumental1.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_editar_operaciones.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_eliminar_operaciones.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_eliminar_instrumental.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            JI_FRAME_ESTERILIZACION.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_eliminar_paquete_en_operacion.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_NUEVO_USUARIO.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_EDITAR_USUARIO.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }
        try {
            FI_ELIMINAR_USUARIO.setIcon(true);
        } catch (java.beans.PropertyVetoException e1) {
            e1.printStackTrace();
        }

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/server-1.png"))); // NOI18N
        jMenu1.setText("INSERTAR");

        jMenuItem2.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/herramientas-de-dentista.png"))); // NOI18N
        jMenuItem2.setText("Material quirurgico");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cama-de-hospital.png"))); // NOI18N
        jMenuItem3.setText("Cirugia");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem10.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/nuevo_usuario.png"))); // NOI18N
        jMenuItem10.setText("Nuevo Usuario");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem10);

        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/settings.png"))); // NOI18N
        jMenu2.setText("EDITAR");

        jMenuItem4.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/herramientas-de-dentista.png"))); // NOI18N
        jMenuItem4.setText("instrumento quirurgico");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem4);

        jMenuItem5.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cama-de-hospital.png"))); // NOI18N
        jMenuItem5.setText("Cirugia");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem5);

        jMenuItem11.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/editar_usuario.png"))); // NOI18N
        jMenuItem11.setText("Usuario");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem11);

        jMenuBar1.add(jMenu2);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/garbage.png"))); // NOI18N
        jMenu3.setText("ELIMINAR");

        jMenuItem7.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/herramientas-de-dentista.png"))); // NOI18N
        jMenuItem7.setText("Instrumento quirurgico");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem7);

        jMenuItem8.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/cama-de-hospital.png"))); // NOI18N
        jMenuItem8.setText("Cirugia");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem8);

        jMenuItem9.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/botiquin-de-primeros-auxilios.png"))); // NOI18N
        jMenuItem9.setText("Paquete en operacion");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem9);

        jMenuItem12.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/eliminar_usuario.png"))); // NOI18N
        jMenuItem12.setText("Usuario");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem12);

        jMenuBar1.add(jMenu3);

        jMenu5.setBackground(new java.awt.Color(204, 204, 204));
        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/3d-glasses.png"))); // NOI18N
        jMenu5.setText("BUSCAR");

        jMenuItem6.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/herramientas-de-dentista.png"))); // NOI18N
        jMenuItem6.setText("Instrumentación quirurgica");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem6);

        jMenuBar1.add(jMenu5);

        jMenu6.setBackground(new java.awt.Color(204, 204, 204));
        jMenu6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/server-1.png"))); // NOI18N
        jMenu6.setText("SESIÓN");

        jMenuItem13.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/salir ses.png"))); // NOI18N
        jMenuItem13.setText("Cerrar la sesión");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem13);

        jMenuItem14.setBackground(new java.awt.Color(255, 255, 255));
        jMenuItem14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/nuevo_usuario.png"))); // NOI18N
        jMenuItem14.setText("Abrir todas las interfaces de usuario");
        jMenuItem14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem14ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem14);

        jMenuBar1.add(jMenu6);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
     bandera=false;
        VISIBLES_E_INVISIBLES(false, true, false, false, false, false, false,false,false,false,false);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void tbl_inicialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_inicialMouseClicked
   @SuppressWarnings("UnusedAssignment")
   String dato1_id ="";
        int contador = tbl_inicial.getSelectedRow();//lee el N° de columna  que seleccionamos
        dato1_id = (String) tbl_inicial.getValueAt(contador, 0);//obtiene el valor de una celda 
        
        Constantes.ID_INSTRUMENTO_IMAGEN=dato1_id;
        
        DIALOG_IMAGEN_CON_DATOS DICD=new DIALOG_IMAGEN_CON_DATOS(this, true);
        DICD.setVisible(true);
                
    }//GEN-LAST:event_tbl_inicialMouseClicked

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        String recibe = txt_filtro.getText();
        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_inicial.getModel();
        for (int i = 0; i < tbl_inicial.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_instrumentos ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_stock");
                String dato4 = rss.getString("str_en_operacion");
                String dato5 = rss.getString("str_id_operacion");
                select_nombre_operaciones(dato5);
                if (dato1.contains(recibe) || dato2.contains(recibe) || obtiene_nombre.contains(recibe)) {
                    String instrumentos[] = {dato1, dato2, dato3, dato4, obtiene_nombre};
                    md_inicial.addRow(instrumentos);
                }
                tbl_inicial.getColumnModel().getColumn(4).setMaxWidth(300);
                tbl_inicial.getColumnModel().getColumn(4).setMinWidth(300);
                tbl_inicial.getColumnModel().getColumn(4).setPreferredWidth(300);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Existe un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton16ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        bandera=false;
        VISIBLES_E_INVISIBLES(false, false, false, false, false, false, true,false,false,false,false);  
        tbl_inicial.getColumnModel().getColumn(4).setMaxWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setMinWidth(0);
        tbl_inicial.getColumnModel().getColumn(4).setPreferredWidth(0);
        DefaultTableModel ACTIVO = (DefaultTableModel) tbl_inicial.getModel();
        for (int i = 0; i < tbl_inicial.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_instrumentos ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_stock");
                String dato4 = rss.getString("str_en_operacion");

                String instrumentos[] = {dato1, dato2, dato3, dato4};
                md_inicial.addRow(instrumentos);

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Existe un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        bandera=false;
        VISIBLES_E_INVISIBLES(true, false, false, false, false, false, false,false,false,false,false);
        select_llenado_insert_quirur_operacion();
    }//GEN-LAST:event_jMenuItem2ActionPerformed
boolean bandera=false;
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        @SuppressWarnings("UnusedAssignment")
        String id="";
        
        id=txt_insert_id_quirurgico.getText();
     
       if(!id.equals("")&&!id.contains(" ")){
            SELECT_INSERT_QUIRURGICO SIQ=new SELECT_INSERT_QUIRURGICO();
            SIQ.select(id);
           
            if(SIQ.bandera==true){
                lbl_noti_insert.setForeground(Color.red);
                   lbl_noti_insert.setText("No disponible");
                    bandera=false;
            }else{
             lbl_noti_insert.setForeground(new java.awt.Color(0, 153, 0));
             lbl_noti_insert.setText("Disponible");
             bandera=true;
         }  
            
        }else{
            lbl_noti_insert.setForeground(Color.red);
                   lbl_noti_insert.setText("No disponible");
                    bandera=false; 
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmb_insert_operacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_insert_operacionActionPerformed
   String recibe_item=cmb_insert_operacion.getSelectedItem().toString();
   String convertidor="";
   for(int i=0;i<=recibe_item.length();i++){
//       recibe_item.substring(i, i+1);
       if (  recibe_item.substring(i, i+1).equals("-")) {
           break;
       }else{
           convertidor+=recibe_item.substring(i, i+1);
       }
   }
        txt_insert_operacion.setText(""+convertidor);
       
       
    }//GEN-LAST:event_cmb_insert_operacionActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    
        
        File archivo_direccion=new File("vacio.png");
        @SuppressWarnings("UnusedAssignment")
        String archi="";
        if(archivo==null){
    JOptionPane.showMessageDialog(null, "No añadiste ninguna imagen se otorgara una por defecto");
    archivo=archivo_direccion;
        System.out.println(""+archivo);
     }else{
     archi=""+archivo.toString();  
     int longitud1=archi.length()-4;
     int longitud2=archi.length();
     archi=archi.substring(longitud1,longitud2);
    
    if(archi.equals(".png")){
       
    }else{
      archivo=archivo_direccion;
    }
        }
        
        
        if(bandera==true){
        String dato1_id="",dato2_nombre_inst="", dato3_stock_inst="", dato4_operacion="";
      dato1_id=txt_insert_id_quirurgico.getText();
      dato2_nombre_inst=txt_insert_nombre_quirurgico.getText();
      dato3_stock_inst=txt_insert_stock_quirur.getText();
      dato4_operacion=txt_insert_operacion.getText();
      if((dato1_id.equals("")||dato1_id.contains(" "))||dato2_nombre_inst.equals("")||dato3_stock_inst.equals("")||dato4_operacion.equals("")
         ||dato4_operacion.equals("-selecciona-")){
          JOptionPane.showMessageDialog(null, "Debes llenar todos los campos","Error",JOptionPane.ERROR_MESSAGE);
      }else{
          INSERT_NUEVO_INST_QUIRURGICO INIQ=new INSERT_NUEVO_INST_QUIRURGICO();
          INIQ.insertar(dato1_id,dato2_nombre_inst,dato3_stock_inst,dato4_operacion,archivo);
          if(INIQ.mensaje==true){
      txt_insert_id_quirurgico.setText("");
      txt_insert_nombre_quirurgico.setText("");
      txt_insert_stock_quirur.setText("");
      txt_insert_operacion.setText(""); 
      cmb_insert_operacion.setSelectedIndex(0);
      lbl_noti_insert.setText("");
       lbl_imagen_nuevo.setText("");
      bandera=false;
      archivo=null;
  select_llenado_id_instrumentos();
          }
      }}else{
          JOptionPane.showMessageDialog(lbl_noti_insert, "DEBES VALIDAR EL ID","IMPORTANTE!",JOptionPane.INFORMATION_MESSAGE);
      }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btn_verificar_operacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_verificar_operacionActionPerformed
       String id="";
         String  dato1="";
        id=txt_nombre_operacion_insert.getText();
     
        if(!id.equals("")){
          dato1=id.substring(0,1);
        }
        if((!id.equals(""))&&(!dato1.equals(" "))){
            SELECT_INSERT_OPERACION_VALIDE SIOV=new SELECT_INSERT_OPERACION_VALIDE();
            SIOV.select(id);
            if(SIOV.bandera==true){
                lbl_valido_operaciones.setForeground(Color.red);
                   lbl_valido_operaciones.setText("No disponible");
                    bandera=false;
            }else{
             lbl_valido_operaciones.setForeground(new java.awt.Color(0, 153, 0));
             lbl_valido_operaciones.setText("Disponible");
              bandera=true;
         }  
        }else{
           lbl_valido_operaciones.setForeground(Color.red);
                  lbl_valido_operaciones.setText("No disponible");
                    bandera=false; 
        }
        
    }//GEN-LAST:event_btn_verificar_operacionActionPerformed

    private void btn_insertar_operacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_insertar_operacionActionPerformed
    if(bandera==true){
        String dato1_nombre="",dato2_descripcion="";
      dato1_nombre=txt_nombre_operacion_insert.getText();
      dato2_descripcion=txt_descripcion_operacion_insert.getText();
      
      if((dato1_nombre.equals(""))){
          JOptionPane.showMessageDialog(null, "Debes llenar por lo menos el campo nombre para la operacion","Error",JOptionPane.ERROR_MESSAGE);
      }else{
          if(dato2_descripcion.isEmpty()){
              dato2_descripcion="Sin descripcion previa";
          }
          INSERT_NUEVA_OPERACION_QUI INOQ=new INSERT_NUEVA_OPERACION_QUI();
          INOQ.insertar(dato2_descripcion,dato1_nombre);
          if(INOQ.mensaje==true){
      txt_nombre_operacion_insert.setText("");
      txt_descripcion_operacion_insert.setText("");
      lbl_valido_operaciones.setText("");
      bandera=false;
          }
      }}else{
          JOptionPane.showMessageDialog(lbl_noti_insert, "DEBES VALIDAR EL ID","IMPORTANTE!",JOptionPane.INFORMATION_MESSAGE);
      }
    }//GEN-LAST:event_btn_insertar_operacionActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        
        bandera=false;
        VISIBLES_E_INVISIBLES(false, false, true, false, false, false, false,false,false,false,false);
        select_llenado_id_instrumentos();
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
     bandera=false;
     
        VISIBLES_E_INVISIBLES(false, false, false, true, false, false, false,false,false,false,false);
        select_llenado_insert_quirur_operacion();
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
       bandera=false;
        VISIBLES_E_INVISIBLES(false, false, false, false, true, false, false,false,false,false,false);
        select_llenado_insert_quirur_operacion();
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
bandera=false;
        VISIBLES_E_INVISIBLES(false, false, false, false, false, true, false,false,false,false,false);    
      select_llenado_id_instrumentos();
    }//GEN-LAST:event_jMenuItem7ActionPerformed
Icon icono=null;
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
String id="";
id=txt_id_update.getText();
if(id.equals("")||id.contains(" ")){
    JOptionPane.showMessageDialog(null, "Ingresa un id valido");
}else{
    SELECT_BUSCAR_INSTRUMENTOS_QUIR SBIQ=new SELECT_BUSCAR_INSTRUMENTOS_QUIR();
    try {
        SBIQ.select(id);
         txt_n_i_q_update.setText(""+SBIQ.dato2);
    txt_s_i_q_update.setText(""+SBIQ.dato3);
    txt_instrumentacion_update.setText(""+SBIQ.dato4);
    lbl_imagen_editar.setIcon(SBIQ.icon);
    icono=SBIQ.icon;

    } catch (IOException ex) {
        Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
    }
   
}
    }//GEN-LAST:event_jButton5ActionPerformed

    private void cmb_id_instrumento_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_id_instrumento_updateActionPerformed
         String recibe_item=cmb_id_instrumento_update.getSelectedItem().toString();
   String convertidor="";
   for(int i=0;i<=recibe_item.length();i++){
//       recibe_item.substring(i, i+1);
       if (  recibe_item.substring(i, i+1).equals("-")) {
           break;
       }else{
           convertidor+=recibe_item.substring(i, i+1);
       }
   }
        txt_id_update.setText(""+convertidor);
       
    }//GEN-LAST:event_cmb_id_instrumento_updateActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
   String nombre="",stock="",operacion="";
   nombre=txt_n_i_q_update.getText();
   stock=txt_s_i_q_update.getText();
   operacion=txt_instrumentacion_update.getText();
   
   if(nombre.equals("")||stock.equals("")||operacion.equals("")){
       JOptionPane.showMessageDialog(null, "LLENA TODOS LOS CAMPOS","IMPORTANTE!!",JOptionPane.INFORMATION_MESSAGE);
   }else{
       UPDATE_INSTRUMENTOS UI=new UPDATE_INSTRUMENTOS();
       UI.update_instrumentos(nombre, stock, operacion);
       if(UI.bandera==true){
           JOptionPane.showMessageDialog(null, "ACTUALIZACION EXITOSA");
           Constantes.ID_INSTRUMENTOS="";
           txt_id_update.setText("");
           txt_n_i_q_update.setText("");
           txt_s_i_q_update.setText("");
           txt_instrumentacion_update.setText("");
            lbl_imagen_editar.setText("");
              select_llenado_id_instrumentos();
       }
   }

    }//GEN-LAST:event_jButton6ActionPerformed

    private void cmb_operacion_ins_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_operacion_ins_updateActionPerformed
      String recibe_item=cmb_operacion_ins_update.getSelectedItem().toString();
   String convertidor="";
   for(int i=0;i<=recibe_item.length();i++){
//       recibe_item.substring(i, i+1);
       if (  recibe_item.substring(i, i+1).equals("-")) {
           break;
       }else{
           convertidor+=recibe_item.substring(i, i+1);
       }
   }
        txt_instrumentacion_update.setText(""+convertidor);
       
    }//GEN-LAST:event_cmb_operacion_ins_updateActionPerformed

    private void cmb_operacion_ins_update1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_operacion_ins_update1ActionPerformed
   String recibe_item=cmb_operacion_ins_update1.getSelectedItem().toString();
   String convertidor="";
   for(int i=0;i<=recibe_item.length();i++){
//       recibe_item.substring(i, i+1);
       if (  recibe_item.substring(i, i+1).equals("-")) {
           break;
       }else{
           convertidor+=recibe_item.substring(i, i+1);
       }
   }
        txt_id_operacion_update.setText(""+convertidor);        
    }//GEN-LAST:event_cmb_operacion_ins_update1ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
  String id="";
  id=txt_id_operacion_update.getText();
  if(id.equals("")){
      JOptionPane.showMessageDialog(null, "ingresa un ID","error!!",JOptionPane.ERROR_MESSAGE);
      
  }else{
      SELECT_BUSCAR_OPERACIONES SBO=new SELECT_BUSCAR_OPERACIONES();
      SBO.select(id);
       txt_nombre_p_la_operacion_update.setText(SBO.dato3);
       txt_descripcion_para_operacion_update.setText(SBO.dato2);     
  }
  
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
      
       String dato1="",dato2="";
  dato1=  txt_nombre_p_la_operacion_update.getText();
  dato2=  txt_descripcion_para_operacion_update.getText();       
       if((dato1.equals(""))){
          JOptionPane.showMessageDialog(null, "Debes llenar por lo menos el campo nombre para la operacion","Error",JOptionPane.ERROR_MESSAGE);
      }else{
          if(dato2.isEmpty()){
              dato2="Sin descripcion previa";
          } 
       UPDATE_CIRUGIAS UC=new UPDATE_CIRUGIAS();
       UC.update_instrumentos(dato1, dato2);
       if(UC.bandera==true){
           txt_id_operacion_update.setText("");
       txt_nombre_p_la_operacion_update.setText("");
       txt_descripcion_para_operacion_update.setText(""); 
       Constantes.ID_CIRUGIAS="";
       }
       }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void cmb_operacion_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_operacion_deleteActionPerformed
  String recibe_item=cmb_operacion_delete.getSelectedItem().toString();
   String convertidor="";
   for(int i=0;i<=recibe_item.length();i++){
//       recibe_item.substring(i, i+1);
       if (  recibe_item.substring(i, i+1).equals("-")) {
           break;
       }else{
           convertidor+=recibe_item.substring(i, i+1);
       }
   }
        txt_id_operacion_delete.setText(""+convertidor);
       
    }//GEN-LAST:event_cmb_operacion_deleteActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
       String id="";
  id=txt_id_operacion_delete.getText();
  if(id.equals("")){
      JOptionPane.showMessageDialog(null, "ingresa un ID","error!!",JOptionPane.ERROR_MESSAGE);
      
  }else{
      SELECT_BUSCAR_OPERACIONES SBO=new SELECT_BUSCAR_OPERACIONES();
      SBO.select(id);
       txt_nombre_operacion_delete.setText(SBO.dato3);
       txt_descripcion_operacion_delete.setText(SBO.dato2);     
  }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
         String dato1="",dato2="";
  dato1=  txt_nombre_operacion_delete.getText();
  dato2=  txt_descripcion_operacion_delete.getText();       
      
       if(Constantes.ID_CIRUGIAS.equals("")){
           JOptionPane.showMessageDialog(null, "NO HAY NADA QUE ELIMINAR BUSCA UN ID");
       }else{
      DELETE_CIRUGIA DC=new DELETE_CIRUGIA();
             try {
                 DC.eliminar_proceso();
             } catch (SQLException ex) {
                 Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
             }
       if(DC.bandera==true){
           txt_id_operacion_delete.setText("");
txt_nombre_operacion_delete.setText("");
txt_descripcion_operacion_delete.setText("");
       Constantes.ID_CIRUGIAS="";
       }
       }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
     String id="";
id=txt_id_instrumental_delete.getText();
if(id.equals("")||id.contains(" ")){
    JOptionPane.showMessageDialog(null, "Ingresa un id valido");
}else{
    SELECT_BUSCAR_INSTRUMENTOS_QUIR SBIQ=new SELECT_BUSCAR_INSTRUMENTOS_QUIR();
         try {
             SBIQ.select(id);
             txt_n_i_q_delete.setText(""+SBIQ.dato2);
    txt_s_i_q_delete.setText(""+SBIQ.dato3);
    txt_instrumental_delete.setText(""+SBIQ.dato4);
    lbl_imagen_eliminar.setIcon(SBIQ.icon);
    lbl_imagen_eliminar.setText("");
         } catch (IOException ex) {
             Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
         }
    
}
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
String nombre="",stock="",operacion="";
   nombre=txt_n_i_q_delete.getText();
   stock=txt_s_i_q_delete.getText();
   operacion=txt_instrumental_delete.getText();
   if(nombre.equals("")||stock.equals("")||operacion.equals("")){
       JOptionPane.showMessageDialog(null, "presiona el boton buscar","IMPORTANTE!!",JOptionPane.INFORMATION_MESSAGE);
   }else{
       DELETE_INSTRUMENTAL DI=new DELETE_INSTRUMENTAL();
    try {
        DI.eliminar_proceso();
    } catch (SQLException ex) {
        Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
    }
       if(DI.bandera==true){
          
           Constantes.ID_INSTRUMENTOS="";
           txt_id_operacion_delete.setText("");
           txt_n_i_q_delete.setText("");
           txt_s_i_q_delete.setText("");
           txt_instrumental_delete.setText("");
       }
   }
       
    }//GEN-LAST:event_jButton10ActionPerformed

    private void cmb_id_instrumento_update1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_id_instrumento_update1ActionPerformed
  String recibe_item=cmb_id_instrumento_update1.getSelectedItem().toString();
   String convertidor="";
   for(int i=0;i<=recibe_item.length();i++){
//       recibe_item.substring(i, i+1);
       if (  recibe_item.substring(i, i+1).equals("-")) {
           break;
       }else{
           convertidor+=recibe_item.substring(i, i+1);
       }
   }
        txt_id_instrumental_delete.setText(""+convertidor);
              
    }//GEN-LAST:event_cmb_id_instrumento_update1ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
  String buscar_paquete=""; 
        buscar_paquete=txt_buscar_paquete_en_operacion.getText();
     DefaultTableModel ACTIVO = (DefaultTableModel) tbl_en_operacion.getModel();
        for (int i = 0; i < tbl_en_operacion.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        String sqll = "SELECT * FROM tbl_paquete where str_id_paquete='"+buscar_paquete+"'";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                String dato1 = rss.getString("str_id_paquete");
                String dato2 = rss.getString("str_nombre");
                String dato3 = rss.getString("str_incluye");
                String dato4 = rss.getString("str_cantidad");
                String dato5 = rss.getString("str_departamento");
                String dato6 = rss.getString("str_operacion");
Constantes.CODIGO_DE_BARRAS=dato1;
                String instrumentos[] = {dato1, dato2, dato3, dato4, dato5, dato6};
                md_paquete_operando.addRow(instrumentos);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_NOTIFICACION.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
bandera=false;
        VISIBLES_E_INVISIBLES(false, false, false, false, false, false, false,true,false,false,false);    
      select_llenado_id_instrumentos(); 
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
   DELETE_OPERACION DO=new DELETE_OPERACION();
        try {
            DO.eliminar_proceso();
             DefaultTableModel ACTIVO = (DefaultTableModel) tbl_en_operacion.getModel();
        for (int i = 0; i < tbl_en_operacion.getRowCount(); i++) {
            ACTIVO.removeRow(i);
            i -= 1;
        }
        } catch (SQLException ex) {
            Logger.getLogger(DEVOLUCION.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btn_generar_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_generar_idActionPerformed
   // long numero = ThreadLocalRandom.current().nextLong(0,7 + 1);
        long numero1 = ThreadLocalRandom.current().nextLong(1000,9000 + 1);
        long numero2 = ThreadLocalRandom.current().nextLong(1000,9000 + 1);
        
String codigo="USU-ES-"+""+numero1+""+numero2;//+"7";  
txt_insert_id_usuario.setText(""+codigo);
    }//GEN-LAST:event_btn_generar_idActionPerformed

    private void cmb_insert_tipo_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_insert_tipo_usuarioActionPerformed
  String selecciona="";
  
  selecciona=cmb_insert_tipo_usuario.getSelectedItem().toString();
  if(!selecciona.equals("-selecciona-")){
     txt_insert_tipo_usuario.setText(""+cmb_insert_tipo_usuario.getSelectedItem().toString());  
  }
       
    }//GEN-LAST:event_cmb_insert_tipo_usuarioActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
     String dato1="",dato2="",dato3="",dato4="",dato5="",dato6="";
     
     dato1=txt_insert_id_usuario.getText();
     dato2=txt_insert_nombre_usuario.getText();
     dato3=txt_insert_contraseña.getText();
     dato4=txt_insert_nombre_persona.getText();
     dato5=txt_insert_apellidos.getText();
     dato6=txt_insert_tipo_usuario.getText();
     if(dato1.equals("")||dato2.equals("")||dato3.equals("")||dato4.equals("")||dato5.equals("")||dato6.equals("")){
         JOptionPane.showMessageDialog(null, "Por favor verifica que no existan campos vacios");
     }else{
         INSERT_NUEVO_USUARIO INU=new INSERT_NUEVO_USUARIO();
         INU.insertar(dato1, dato2, dato3, dato4, dato5, dato6);
         if(INU.mensaje==true){
     txt_insert_id_usuario.setText("");
     txt_insert_nombre_usuario.setText("");
     txt_insert_contraseña.setText("");
     txt_insert_nombre_persona.setText("");
     txt_insert_apellidos.setText("");
     txt_insert_tipo_usuario.setText("");
         }
     }
     
     
    }//GEN-LAST:event_jButton14ActionPerformed

    private void txt_insert_apellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_insert_apellidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_insert_apellidosActionPerformed

    private void txt_insert_tipo_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_insert_tipo_usuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_insert_tipo_usuarioActionPerformed

    private void btn_generar_id1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_generar_id1ActionPerformed
   long numero1 = ThreadLocalRandom.current().nextLong(1000,9000 + 1);
        long numero2 = ThreadLocalRandom.current().nextLong(1000,9000 + 1);
        
String codigo="USU-ES-"+""+numero1+""+numero2;//+"7";  
txt_insert_id_usuario1.setText(""+codigo);
    }//GEN-LAST:event_btn_generar_id1ActionPerformed

    private void txt_insert_apellidos1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_insert_apellidos1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_insert_apellidos1ActionPerformed

    private void cmb_tipo_usuario1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_tipo_usuario1ActionPerformed
      String selecciona="";
  
  selecciona=cmb_tipo_usuario1.getSelectedItem().toString();
  if(!selecciona.equals("-selecciona-")){
     
      txt_insert_tipo_usuario1.setText(""+cmb_tipo_usuario1.getSelectedItem().toString());
  }
     
    }//GEN-LAST:event_cmb_tipo_usuario1ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
String dato1="",dato2="",dato3="",dato4="",dato5="",dato6="";

     dato1=txt_insert_id_usuario1.getText();
     dato2=txt_insert_nombre_usuario1.getText();
     dato3=txt_insert_contraseña1.getText();
     dato4=txt_insert_nombre_persona1.getText();
     dato5=txt_insert_apellidos1.getText();
     dato6=txt_insert_tipo_usuario1.getText();
   if(dato1.equals("")||dato2.equals("")||dato3.equals("")||dato4.equals("")||dato5.equals("")||dato6.equals("")){
         JOptionPane.showMessageDialog(null, "Por favor verifica que no existan campos vacios");
     }else{
         UPDATE_USUARIOS UU=new UPDATE_USUARIOS();
         UU.update_usuario(dato1, dato2, dato3, dato4, dato5, dato6);
         if(UU.bandera==true){
     txt_insert_id_usuario1.setText("");
     txt_insert_nombre_usuario1.setText("");
     txt_insert_contraseña1.setText("");
     txt_insert_nombre_persona1.setText("");
     txt_insert_apellidos1.setText("");
     txt_insert_tipo_usuario1.setText("");
         }
     }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void txt_insert_tipo_usuario1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_insert_tipo_usuario1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_insert_tipo_usuario1ActionPerformed

    private void cmb_id_usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_id_usuarioActionPerformed
       
        String selecciona="";
  
  selecciona=cmb_id_usuario.getSelectedItem().toString();
  if(!selecciona.equals("-selecciona-")){
      selecciona=cmb_id_usuario.getSelectedItem().toString();
         try {
            select_buscar_usuario(selecciona);
        } catch (SQLException ex) {
            Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
        } 
      
      
       txt_buscar_usuario.setText(""+cmb_id_usuario.getSelectedItem().toString());
  }
     
    }//GEN-LAST:event_cmb_id_usuarioActionPerformed

    private void btn_generar_id2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_generar_id2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_generar_id2ActionPerformed

    private void txt_insert_apellidos2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_insert_apellidos2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_insert_apellidos2ActionPerformed

    private void cmb_tipo_usuario2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_tipo_usuario2ActionPerformed
       String selecciona="";
  
  selecciona=cmb_tipo_usuario2.getSelectedItem().toString();
  if(!selecciona.equals("-selecciona-")){
    
      txt_insert_tipo_usuario2.setText(""+cmb_tipo_usuario2.getSelectedItem().toString());
  }
    }//GEN-LAST:event_cmb_tipo_usuario2ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
    String dato1="";

     dato1=txt_insert_id_usuario2.getText();
   
   if(dato1.equals("")){
         JOptionPane.showMessageDialog(null, "Por favor verifica que no existan campos vacios");
     }else{
      DELETE_USUARIO DU=new DELETE_USUARIO();
        try {
            DU.eliminar_USUARIO(dato1);
                 if(DU.bandera==true){
     txt_insert_id_usuario2.setText("");
     txt_insert_nombre_usuario2.setText("");
     txt_insert_contraseña2.setText("");
     txt_insert_nombre_persona2.setText("");
     txt_insert_apellidos2.setText("");
     txt_insert_tipo_usuario2.setText("");
         }
        } catch (SQLException ex) {
            Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
        }
    
     }
    
    }//GEN-LAST:event_jButton17ActionPerformed

    private void txt_insert_tipo_usuario2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_insert_tipo_usuario2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_insert_tipo_usuario2ActionPerformed

    private void cmb_id_usuario1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmb_id_usuario1ActionPerformed
       String selecciona="";
  
  selecciona=cmb_id_usuario1.getSelectedItem().toString();
  if(!selecciona.equals("-selecciona-")){
      selecciona=cmb_id_usuario1.getSelectedItem().toString();
         try {
            select_buscar_usuario_DELETE(selecciona);
        } catch (SQLException ex) {
            Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
        } 
      
      
       txt_buscar_usuario1.setText(""+cmb_id_usuario1.getSelectedItem().toString());
  }
    }//GEN-LAST:event_cmb_id_usuario1ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
    bandera=false;
        VISIBLES_E_INVISIBLES(false, false, false, false, false, false, false,false,true,false,false);
        select_llenado_insert_quirur_operacion();        
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
           bandera=false;
        VISIBLES_E_INVISIBLES(false, false, false, false, false, false, false,false,false,true,false);
      select_llenado_id_usuarios();     
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
         bandera=false;
        VISIBLES_E_INVISIBLES(false, false, false, false, false, false, false,false,false,false,true);
        select_llenado_id_usuarios(); 
        
     
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       JFileChooser selectorArchivos = new JFileChooser();
selectorArchivos.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

FileNameExtensionFilter filtro = new FileNameExtensionFilter("imagenes", "png");
selectorArchivos.setFileFilter(filtro);

// indica cual fue la accion de usuario sobre el jfilechooser
int resultado = selectorArchivos.showOpenDialog(this);

System.out.println("esto es archivo_: "+archivo);
System.out.println("esto es resultado_: "+resultado);

if(resultado==JFileChooser.APPROVE_OPTION){
    System.out.println("esto es resultado_: "+resultado);
     archivo = selectorArchivos.getSelectedFile(); // obtiene el archivo seleccionado
       ImageIcon img = null;
           try {
               img = new ImageIcon(selectorArchivos.getSelectedFile().toURL());
           } catch (MalformedURLException ex) {
               Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
           }
          Icon icono = new ImageIcon(img.getImage().getScaledInstance(lbl_imagen_nuevo.getWidth(),lbl_imagen_nuevo.getHeight(), Image.SCALE_DEFAULT));

           lbl_imagen_nuevo.setText("");
      lbl_imagen_nuevo.setIcon(img);
// lbl_imagen_subir.setText(archivo.getAbsolutePath());
Scanner scn = null;
       try {
           scn = new Scanner(archivo);
       } catch (FileNotFoundException ex) {
         JOptionPane.showMessageDialog(this, "Nombre de archivo inválido deben ser imagenes en formato PNG ", "Nombre de archivo inválido", JOptionPane.ERROR_MESSAGE);
archivo=null;
       }
}else{
    JOptionPane.showMessageDialog(this, "Nombre de archivo inválido deben ser imagenes en formato PNG ", "Nombre de archivo inválido", JOptionPane.ERROR_MESSAGE);
archivo=null;
}

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
      JFileChooser selectorArchivos = new JFileChooser();
selectorArchivos.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

FileNameExtensionFilter filtro = new FileNameExtensionFilter("imagenes", "png");
selectorArchivos.setFileFilter(filtro);

// indica cual fue la accion de usuario sobre el jfilechooser
int resultado = selectorArchivos.showOpenDialog(this);

System.out.println("esto es archivo_: "+archivo);
System.out.println("esto es resultado_: "+resultado);

if(resultado==JFileChooser.APPROVE_OPTION){
    System.out.println("esto es resultado_: "+resultado);
     archivo = selectorArchivos.getSelectedFile(); // obtiene el archivo seleccionado
       ImageIcon img = null;
           try {
               img = new ImageIcon(selectorArchivos.getSelectedFile().toURL());
           } catch (MalformedURLException ex) {
               Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
           }
          Icon icono = new ImageIcon(img.getImage().getScaledInstance(lbl_imagen_editar.getWidth(),lbl_imagen_editar.getHeight(), Image.SCALE_DEFAULT));

           lbl_imagen_editar.setText("");
      lbl_imagen_editar.setIcon(img);
// lbl_imagen_subir.setText(archivo.getAbsolutePath());
Scanner scn = null;
       try {
           scn = new Scanner(archivo);
       } catch (FileNotFoundException ex) {
         JOptionPane.showMessageDialog(this, "Nombre de archivo inválido deben ser imagenes en formato PNG ", "Nombre de archivo inválido", JOptionPane.ERROR_MESSAGE);
archivo=null;
       }
}else{
    JOptionPane.showMessageDialog(this, "Nombre de archivo inválido deben ser imagenes en formato PNG ", "Nombre de archivo inválido", JOptionPane.ERROR_MESSAGE);
archivo=null;
}
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
      File archivo_direccion=new File("vacio.png");
        String archi="";
        if(archivo==null){
    JOptionPane.showMessageDialog(null, "No añadiste ninguna imagen se otorgara una por defecto");
    archivo=archivo_direccion;
        System.out.println(""+archivo);
     }else{
     archi=""+archivo.toString();  
     int longitud1=archi.length()-4;
     int longitud2=archi.length();
     archi=archi.substring(longitud1,longitud2);
    
    if(archi.equals(".png")){
       
    }else{
      archivo=archivo_direccion;
    }
        }
        
        
       
       String nombre="",stock="",operacion="";
   nombre=txt_n_i_q_update.getText();
   stock=txt_s_i_q_update.getText();
   operacion=txt_instrumentacion_update.getText();
   
   if(nombre.equals("")||stock.equals("")||operacion.equals("")){
       JOptionPane.showMessageDialog(null, "LLENA TODOS LOS CAMPOS","IMPORTANTE!!",JOptionPane.INFORMATION_MESSAGE);
   }else{
       UPDATE_INSTRUMENTOS_IMAGEN UII=new UPDATE_INSTRUMENTOS_IMAGEN();
          try {
              UII.update_instrumentos(nombre, stock, operacion,archivo);
               if(UII.bandera==true){
           JOptionPane.showMessageDialog(null, "ACTUALIZACION EXITOSA");
           Constantes.ID_INSTRUMENTOS="";
           txt_id_update.setText("");
           txt_n_i_q_update.setText("");
           txt_s_i_q_update.setText("");
           txt_instrumentacion_update.setText("");
            lbl_imagen_editar.setText("");
              select_llenado_id_instrumentos();
           archivo=null;
       }
          } catch (FileNotFoundException ex) {
              Logger.getLogger(VENTANA_ADMIN_ADMIN.class.getName()).log(Level.SEVERE, null, ex);
          }
      
   }

    }//GEN-LAST:event_jButton19ActionPerformed

    private void txt_insert_stock_quirurKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_insert_stock_quirurKeyTyped
        if (!(evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9')) {
            evt.consume();
        }
    }//GEN-LAST:event_txt_insert_stock_quirurKeyTyped

    private void txt_s_i_q_updateKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_s_i_q_updateKeyTyped
        if (!(evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9')) {
            evt.consume();
        }
    }//GEN-LAST:event_txt_s_i_q_updateKeyTyped

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
  Constantes.ID="";
        Constantes.CANTIDAD="";
        Constantes.NOMBRE_PAQUETE="";
        Constantes.ID_USUARIO="";
        Constantes.ID_TIPO_USUARIO="";
        Constantes.ID_NOMBRE_USUARIO="";
        Constantes.CODIGO_DE_BARRAS="";
        Constantes.INCLUYE="";
        Constantes.DEPARTAMENTO="";
        Constantes.ENVIAR_A="";
        Constantes.ULTIMO_DIGITO="";
        Constantes.ID_INSTRUMENTOS="";
        Constantes.ID_CIRUGIAS="";
        Constantes.DIRECCION_PDF="";
        Constantes.ID_INSTRUMENTO_IMAGEN="";
 
  VU.setVisible(false);

  VAM.setVisible(false);
  Constantes.VENTANAS=false;
  
  
  this.dispose();
  LOGUEO LO=new LOGUEO();
  LO.setVisible(true);
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    
     VENTANA_ADMINISTRADOR_MONITORISTA VAM=new VENTANA_ADMINISTRADOR_MONITORISTA();
    VENTANA_USUARIO VU = new VENTANA_USUARIO();
    private void jMenuItem14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem14ActionPerformed
Constantes.VENTANAS=true;
        
        VU.setVisible(true);
       
        VAM.setVisible(true);
    }//GEN-LAST:event_jMenuItem14ActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JInternalFrame FI_EDITAR_USUARIO;
    private javax.swing.JInternalFrame FI_ELIMINAR_USUARIO;
    private javax.swing.JInternalFrame FI_NUEVO_USUARIO;
    private javax.swing.JInternalFrame FI_editar_instrumental1;
    private javax.swing.JInternalFrame FI_editar_operaciones;
    private javax.swing.JInternalFrame FI_eliminar_instrumental;
    private javax.swing.JInternalFrame FI_eliminar_operaciones;
    private javax.swing.JInternalFrame FI_eliminar_paquete_en_operacion;
    private javax.swing.JInternalFrame FI_insert_instrumental;
    private javax.swing.JInternalFrame FI_insert_operaciones;
    private javax.swing.JInternalFrame JI_FRAME_ESTERILIZACION;
    private javax.swing.JButton btn_generar_id;
    private javax.swing.JButton btn_generar_id1;
    private javax.swing.JButton btn_generar_id2;
    private javax.swing.JButton btn_insertar_operacion;
    private javax.swing.JButton btn_verificar_operacion;
    private javax.swing.JComboBox cmb_id_instrumento_update;
    private javax.swing.JComboBox cmb_id_instrumento_update1;
    private javax.swing.JComboBox cmb_id_usuario;
    private javax.swing.JComboBox cmb_id_usuario1;
    private javax.swing.JComboBox cmb_insert_operacion;
    private javax.swing.JComboBox cmb_insert_tipo_usuario;
    private javax.swing.JComboBox cmb_operacion_delete;
    private javax.swing.JComboBox cmb_operacion_ins_update;
    private javax.swing.JComboBox cmb_operacion_ins_update1;
    private javax.swing.JComboBox cmb_tipo_usuario1;
    private javax.swing.JComboBox cmb_tipo_usuario2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem14;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JLabel lbl_imagen_editar;
    private javax.swing.JLabel lbl_imagen_eliminar;
    private javax.swing.JLabel lbl_imagen_nuevo;
    private javax.swing.JLabel lbl_noti_insert;
    private javax.swing.JLabel lbl_noti_insert1;
    private javax.swing.JLabel lbl_noti_insert2;
    private javax.swing.JLabel lbl_noti_insert3;
    private javax.swing.JLabel lbl_valido_operaciones;
    private org.edisoncor.gui.panel.Panel panel1;
    private org.edisoncor.gui.panel.Panel panel2;
    private javax.swing.JTable tbl_en_operacion;
    private javax.swing.JTable tbl_inicial;
    private javax.swing.JTextField txt_buscar_paquete_en_operacion;
    private javax.swing.JTextField txt_buscar_usuario;
    private javax.swing.JTextField txt_buscar_usuario1;
    private javax.swing.JTextArea txt_descripcion_operacion_delete;
    private javax.swing.JTextArea txt_descripcion_operacion_insert;
    private javax.swing.JTextArea txt_descripcion_para_operacion_update;
    private javax.swing.JTextField txt_filtro;
    private javax.swing.JTextField txt_id_instrumental_delete;
    private javax.swing.JTextField txt_id_operacion_delete;
    private javax.swing.JTextField txt_id_operacion_update;
    private javax.swing.JTextField txt_id_update;
    private javax.swing.JTextField txt_insert_apellidos;
    private javax.swing.JTextField txt_insert_apellidos1;
    private javax.swing.JTextField txt_insert_apellidos2;
    private javax.swing.JTextField txt_insert_contraseña;
    private javax.swing.JTextField txt_insert_contraseña1;
    private javax.swing.JTextField txt_insert_contraseña2;
    private javax.swing.JTextField txt_insert_id_quirurgico;
    private javax.swing.JTextField txt_insert_id_usuario;
    private javax.swing.JTextField txt_insert_id_usuario1;
    private javax.swing.JTextField txt_insert_id_usuario2;
    private javax.swing.JTextField txt_insert_nombre_persona;
    private javax.swing.JTextField txt_insert_nombre_persona1;
    private javax.swing.JTextField txt_insert_nombre_persona2;
    private javax.swing.JTextField txt_insert_nombre_quirurgico;
    private javax.swing.JTextField txt_insert_nombre_usuario;
    private javax.swing.JTextField txt_insert_nombre_usuario1;
    private javax.swing.JTextField txt_insert_nombre_usuario2;
    private javax.swing.JTextField txt_insert_operacion;
    private javax.swing.JTextField txt_insert_stock_quirur;
    private javax.swing.JTextField txt_insert_tipo_usuario;
    private javax.swing.JTextField txt_insert_tipo_usuario1;
    private javax.swing.JTextField txt_insert_tipo_usuario2;
    private javax.swing.JTextField txt_instrumentacion_update;
    private javax.swing.JTextField txt_instrumental_delete;
    private javax.swing.JTextField txt_n_i_q_delete;
    private javax.swing.JTextField txt_n_i_q_update;
    private javax.swing.JTextField txt_nombre_operacion_delete;
    private javax.swing.JTextField txt_nombre_operacion_insert;
    private javax.swing.JTextField txt_nombre_p_la_operacion_update;
    private javax.swing.JTextField txt_s_i_q_delete;
    private javax.swing.JTextField txt_s_i_q_update;
    // End of variables declaration//GEN-END:variables
 String obtiene_nombre = "";
   public void select_llenado_id_usuarios(){
          cmb_id_usuario.setModel(new javax.swing.DefaultComboBoxModel(new String[]{}));
        cmb_id_usuario.addItem("-selecciona-");
          cmb_id_usuario1.setModel(new javax.swing.DefaultComboBoxModel(new String[]{}));
        cmb_id_usuario1.addItem("-selecciona-");
        
          @SuppressWarnings("UnusedAssignment")
        String  dato1="";
      
        String sqll = "SELECT * FROM tbl_usuario ORDER BY str_id_usuario ASC ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                dato1 = rss.getString("str_id_usuario");
              cmb_id_usuario.addItem(dato1);
              cmb_id_usuario1.addItem(dato1);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al llenar los ITEMS\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_INSERT_QUIRURGICO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void select_nombre_operaciones(String dato5) {
        String sqll = "SELECT * FROM tbl_n_operacion where str_id_operacion='" + dato5 + "'";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {

                obtiene_nombre = rss.getString("str_nombre_operacion");

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Existe un error al obtener los datos vuelve a intentar\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "STQH-INTERFACING", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(VENTANA_ADMINISTRADOR_MONITORISTA.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void select_llenado_insert_quirur_operacion(){
           cmb_insert_operacion.setModel(new javax.swing.DefaultComboBoxModel(new String[]{}));
        cmb_insert_operacion.addItem("-selecciona-");
        cmb_operacion_ins_update.setModel(new javax.swing.DefaultComboBoxModel(new String[]{}));
       cmb_operacion_ins_update.addItem("-selecciona-");
        cmb_operacion_ins_update1.setModel(new javax.swing.DefaultComboBoxModel(new String[]{}));
        cmb_operacion_ins_update1.addItem("-selecciona-");
         cmb_operacion_delete.setModel(new javax.swing.DefaultComboBoxModel(new String[]{}));
         cmb_operacion_delete.addItem("-selecciona-");
        
        String  dato1="";
         String  dato2="";     
        String sqll = "SELECT * FROM tbl_n_operacion ORDER BY str_id_operacion ASC ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                dato1 = rss.getString("str_id_operacion");
                dato2 = rss.getString("str_nombre_operacion");
              cmb_insert_operacion.addItem(dato1+"-"+dato2);
              cmb_operacion_ins_update.addItem(dato1+"-"+dato2);
              cmb_operacion_ins_update1.addItem(dato1+"-"+dato2);
              cmb_operacion_delete.addItem(dato1+"-"+dato2);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al llenar los ITEMS\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_INSERT_QUIRURGICO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void select_llenado_id_instrumentos(){
             String dato1="",dato2="";  
        String sqll = "SELECT * FROM tbl_instrumentos ORDER BY str_id ASC ";
        Statement stt;
        try {
            stt = cnu.createStatement();
            ResultSet rss = stt.executeQuery(sqll);

            while (rss.next()) {
                dato1 = rss.getString("str_id");
                dato2 = rss.getString("str_nombre");
            cmb_id_instrumento_update.addItem(dato1+"-"+dato2);
            cmb_id_instrumento_update1.addItem(dato1+"-"+dato2);
           
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Se encontro un error al llenar los ITEMS\n"
                    + "si el problema sigue consulta a los especialistas de mantenimiento del sistema\n"
                    + "APLICACIONES LC", "APLICACIONES LC", JOptionPane.INFORMATION_MESSAGE);

            Logger.getLogger(SELECT_INSERT_QUIRURGICO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void VISIBLES_E_INVISIBLES(boolean a,boolean b,boolean c,boolean d,boolean e,boolean f,boolean g,boolean h,boolean i,boolean j,boolean k){
   if(a==true){
      FI_insert_instrumental.setVisible(true);  
   }else{
     FI_insert_instrumental.hide();
   }
    if(b==true){
      FI_insert_operaciones.setVisible(b);
   }else{
     FI_insert_operaciones.hide();
   }
     if(c==true){
      FI_editar_instrumental1.setVisible(c);
   }else{
      FI_editar_instrumental1.hide();
   }
      if(d==true){
    FI_editar_operaciones.setVisible(d);
   }else{
    FI_editar_operaciones.hide();
   }
       if(e==true){
       FI_eliminar_operaciones.setVisible(e);
   }else{
        FI_eliminar_operaciones.hide();
   }
        if(f==true){
       FI_eliminar_instrumental.setVisible(f);
   }else{
     FI_eliminar_instrumental.hide();
   }
         if(g==true){
     JI_FRAME_ESTERILIZACION.setVisible(g); 
   }else{
     JI_FRAME_ESTERILIZACION.hide();
   }
          if(h==true){
     FI_eliminar_paquete_en_operacion.setVisible(h); 
   }else{
    FI_eliminar_paquete_en_operacion.hide();
   }
            if(i==true){
     FI_NUEVO_USUARIO.setVisible(i); 
   }else{
    FI_NUEVO_USUARIO.hide();
   }
            if(j==true){
     FI_EDITAR_USUARIO.setVisible(j); 
   }else{
    FI_EDITAR_USUARIO.hide();
   }
                 if(k==true){
     FI_ELIMINAR_USUARIO.setVisible(k); 
   }else{
    FI_ELIMINAR_USUARIO.hide();
   }
    
   
   
    
  
  
   

  
    }

    private void select_buscar_usuario(String selecciona) throws SQLException {
          String dato1 = "";
      String dato2 = "";
      String dato3 = "";
      String dato4 = "";
      String dato5 = "";
      String dato6 = "";
      
        PreparedStatement pstmt = cnu.prepareStatement("SELECT * FROM tbl_usuario WHERE str_id_usuario=  ? ");

pstmt.setString(1, selecciona);

//Obtengo el resultado de la consulta
ResultSet rs = pstmt.executeQuery();


//Si encuentra algo imprime el primer campo de los registro
while (rs.next()) {
      dato1 = rs.getString("str_id_usuario");
      dato2 = rs.getString("str_n_usuario");
      dato3 = rs.getString("str_n_contra");
      dato4 = rs.getString("str_nombre");
      dato5 = rs.getString("str_apellidos");
      dato6 = rs.getString("str_t_usuario");
      
       txt_insert_id_usuario1.setText(""+dato1);
     txt_insert_nombre_usuario1.setText(""+dato2);
     txt_insert_contraseña1.setText(""+dato3);
     txt_insert_nombre_persona1.setText(""+dato4);
     txt_insert_apellidos1.setText(""+dato5);
     txt_insert_tipo_usuario1.setText(""+dato6);
}
      
    }

    private void select_buscar_usuario_DELETE(String selecciona)throws SQLException {
          String dato1 = "";
      String dato2 = "";
      String dato3 = "";
      String dato4 = "";
      String dato5 = "";
      String dato6 = "";
      
        PreparedStatement pstmt = cnu.prepareStatement("SELECT * FROM tbl_usuario WHERE str_id_usuario=  ? ");

pstmt.setString(1, selecciona);

//Obtengo el resultado de la consulta
ResultSet rs = pstmt.executeQuery();


//Si encuentra algo imprime el primer campo de los registro
while (rs.next()) {
      dato1 = rs.getString("str_id_usuario");
      dato2 = rs.getString("str_n_usuario");
      dato3 = rs.getString("str_n_contra");
      dato4 = rs.getString("str_nombre");
      dato5 = rs.getString("str_apellidos");
      dato6 = rs.getString("str_t_usuario");
      
       txt_insert_id_usuario2.setText(""+dato1);
     txt_insert_nombre_usuario2.setText(""+dato2);
     txt_insert_contraseña2.setText(""+dato3);
     txt_insert_nombre_persona2.setText(""+dato4);
     txt_insert_apellidos2.setText(""+dato5);
     txt_insert_tipo_usuario2.setText(""+dato6);
}
      
    }
}
