/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CAMBIO_DE_COLOR_CELDAS;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author ERICK IVAN
 */
public class CellRenderer extends DefaultTableCellRenderer implements TableCellRenderer {
    private static final long serialVersionUID = 1L; 

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        //establecemos el fondo blanco o vacío
        setBackground(null);
       
        //COnstructor de la clase DefaultTableCellRenderer
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
if((column==5&& value.equals("esperando"))||(column==6&& value.equals("esperando"))||(column==7&& value.equals("esperando"))||(column==8&& value.equals("esperando"))
                                          ||(column==9&& value.equals("esperando"))||(column==10&& value.equals("esperando"))){
     Color  c = new Color(255, 87, 51);
  setBackground(c);
}

if((column==5&& value.equals("aprobado"))||(column==6&& value.equals("aprobado"))||(column==7&& value.equals("aprobado"))||(column==8&& value.equals("aprobado"))
                                         ||(column==9&& value.equals("aprobado"))||(column==10&& value.equals("aprobado"))){
     Color  c = new Color(16, 189, 26);
  setBackground(c);
}

if((column==5&& value.equals("procesando"))||(column==6&& value.equals("procesando"))||(column==7&& value.equals("procesando"))||(column==8&& value.equals("procesando"))
                                           ||(column==9&& value.equals("procesando"))||(column==10&& value.equals("procesando"))){
     Color  c = new Color(220, 229, 24);
  setBackground(c);
}





//if(column==5&& value.equals("esperando")){
//     Color  c = new Color(255, 87, 51);
//  setBackground(c);
//}
//if(column==6&& value.equals("esperando")){
//     Color  c = new Color(255, 87, 51);
//  setBackground(c);
//}
//if(column==7&& value.equals("esperando")){
//     Color  c = new Color(255, 87, 51);
//  setBackground(c);
//}
        return this;
    }

}
